jQuery_1_2_3(function() {
  jQuery_1_2_3('.error').hide();
  jQuery_1_2_3('input.text-input').css({backgroundColor:"#FFFFFF"});
  jQuery_1_2_3('input.text-input').focus(function(){
    jQuery_1_2_3(this).css({backgroundColor:"#FFDDAA"});
  });
  jQuery_1_2_3('input.text-input').blur(function(){
    jQuery_1_2_3(this).css({backgroundColor:"#FFFFFF"});
  });

  jQuery_1_2_3(".button").click(function() {
		// validate and process form
		// first hide any error messages
    jQuery_1_2_3('.error').hide();
		
	  var name = jQuery_1_2_3("input#name").val();
		if (name == "") {
      jQuery_1_2_3("label#name_error").show();
      jQuery_1_2_3("input#name").focus();
      return false;
    }
		var email = jQuery_1_2_3("input#email").val();
		if (email == "") {
      jQuery_1_2_3("label#email_error").show();
      jQuery_1_2_3("input#email").focus();
      return false;
    }
		var country = jQuery_1_2_3("select#country").val();
		if (country == "") {
      jQuery_1_2_3("label#country_error").show();
      jQuery_1_2_3("select#country").focus();
      return false;
    }
	
	var comment = jQuery_1_2_3("textarea#comment").val();
		if (comment == "") {
      jQuery_1_2_3("label#comment_error").show();
      jQuery_1_2_3("textarea#comment").focus();
      return false;
    }
	
		
		var dataString = 'name='+ name + '&email=' + email + '&country=' + country + '&comment=' + comment;
		//alert (dataString);return false;
		
		jQuery_1_2_3.ajax({
      type: "POST",
      url: "bin/process.php",
      data: dataString,
      success: function() {
        jQuery_1_2_3('#contact_form').html("<div id='message'></div>");
        jQuery_1_2_3('#message').html("<h1>Success!</h1>")
        .append("<p>Thank you for sharing your expectation.</p>")
        .hide()
        .fadeIn(1500, function() {
          jQuery_1_2_3('#message').append("<img id='checkmark' src='images/check.png' />");
        });
      }
     });
    return false;
	});
});
runOnLoad(function(){
  jQuery_1_2_3("input#name").select().focus();
});
