/*package com.loveworldsat.app;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;

import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

   public class IwitnessPhoto extends Activity {
   TextView path;
   String selectedImagePath;
   String selectedFileName;
   ProgressDialog dialog = null;
   @Override

   protected void onCreate(Bundle savedInstanceState) {
   super.onCreate(savedInstanceState);
   setContentView(R.layout.activity_iwitness);
   Button btnUpload = (Button)findViewById(R.id.vid);
   Button btnSelect = (Button)findViewById(R.id.pix);
   //path = (TextView) findViewById(R.id.path);

   btnUpload.setOnClickListener(new OnClickListener(){

   public void onClick(View v) {
   dialog = ProgressDialog.show(IwitnessPhoto.this, "", "Uploading file...", true);
                 new Thread(new Runnable() {
                        public void run() {
                                             
                        doUpload();                    
                        }
                      }).start();        
                }
   });
   btnSelect.setOnClickListener(new OnClickListener(){

   @Override
   public void onClick(View v) {
   doSelect();

   }
   });
  }

   private void doUpload() {
   try
   {
          if (selectedImagePath != null){
       	   Bitmap bm = BitmapFactory.decodeFile(selectedImagePath);
       	  
       	   executeMultipartPost(bm);
          }
          
       } catch (Exception e) {
           Log.e(e.getClass().getName(), e.getMessage());
       }
   }

   private void executeMultipartPost(Bitmap bm) throws Exception{
   try
      {
           ByteArrayOutputStream bos = new ByteArrayOutputStream();
           bm.compress(CompressFormat.JPEG, 75, bos);
           byte[] data = bos.toByteArray();
           HttpClient httpClient = new DefaultHttpClient();
           HttpPost postRequest = new HttpPost(
                   "http://videoshare.loveworldapis.com/picupload/upload.php");
           ByteArrayBody bab = new ByteArrayBody(data, selectedFileName + ".jpg");
           // File file= new File("/mnt/sdcard/forest.png");
           // FileBody bin = new FileBody(file);
           MultipartEntity reqEntity = new MultipartEntity(
                   HttpMultipartMode.BROWSER_COMPATIBLE);
           reqEntity.addPart("upload", bab);
           reqEntity.addPart("title", new StringBody("I love Eko"));
           postRequest.setEntity(reqEntity);
           
           HttpResponse response = httpClient.execute(postRequest);
           BufferedReader reader = new BufferedReader(new InputStreamReader(
                   response.getEntity().getContent(), "UTF-8"));
           String sResponse;
           StringBuilder s = new StringBuilder();
 
           while ((sResponse = reader.readLine()) != null) {
               s = s.append(sResponse);
           }
           Log.i("HTTP", "Response: " + s);
           dialog.dismiss();
         } catch (Exception e) {
           // handle exception here
       	dialog.dismiss();
           Log.e(e.getClass().getName(), e.getMessage());
       }
   }

      private void doSelect(){
      if (Environment.getExternalStorageState().equals("mounted")) {
      Intent intent = new Intent();
      intent.setType("image/*");
      intent.setAction(Intent.ACTION_PICK);
      startActivityForResult(Intent.createChooser(intent,"Select Picture:"),1);

      }
      }

      protected void onActivityResult(int requestCode, int resultCode, Intent data) {

      if (resultCode != RESULT_CANCELED){
      if (requestCode  == 1){
      Uri selectedImageUri = data.getData();
      selectedImagePath = getPath(selectedImageUri);
      path.setText(selectedImagePath);
      Log.i("IMAGE NAME", selectedFileName = getFileName(selectedImageUri));
   
      Log.i("FILE SIZE", getSize(selectedImageUri));
   
   
}
}
   
}
public String getPath(Uri uri) {
   String[] projection = { MediaStore.Images.Media.DATA };
   Cursor cursor = managedQuery(uri, projection, null, null, null);
   int column_index = cursor
       .getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
   cursor.moveToFirst();
   return cursor.getString(column_index);
}
public String getFileName(Uri uri){
String[] projection = { MediaStore.Images.Media.TITLE };
   Cursor cursor = managedQuery(uri, projection, null, null, null);
   int column_index = cursor
       .getColumnIndexOrThrow(MediaStore.Images.Media.TITLE);
   cursor.moveToFirst();
   return cursor.getString(column_index);
}
public String getSize(Uri uri){
String[] projection = { MediaStore.Images.Media.SIZE };
   Cursor cursor = managedQuery(uri, projection, null, null, null);
   int column_index = cursor
       .getColumnIndexOrThrow(MediaStore.Images.Media.SIZE);
   cursor.moveToFirst();
   return cursor.getString(column_index);
}
}*/