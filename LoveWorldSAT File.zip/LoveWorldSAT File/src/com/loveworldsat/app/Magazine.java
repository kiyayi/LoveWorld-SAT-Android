package com.loveworldsat.app;

import java.io.File;

import java.io.FileOutputStream;

import java.io.IOException;

import java.io.InputStream;

import java.net.HttpURLConnection;

import java.net.MalformedURLException;

import java.net.URL;

 

import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;

import android.content.ActivityNotFoundException;
import android.content.DialogInterface;

import android.content.Intent;
import android.content.res.Configuration;

import android.graphics.Color;

import android.graphics.Typeface;

import android.net.Uri;

import android.os.Build;
import android.os.Bundle;

import android.os.Environment;

import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.WindowManager;

import android.widget.TextView;

 

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class Magazine extends Activity {

 

    TextView tv_loading;
    String dest_file_path = "test.pdf";
    int downloadedSize = 0, totalsize;
    String download_file_url = "http://loveworldsat.org/mag/lsat_magazine_august.pdf";
    float per = 0;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tv_loading = new TextView(this);
        setContentView(tv_loading);
        tv_loading.setGravity(Gravity.CENTER);
        tv_loading.setTypeface(null, Typeface.BOLD);
        downloadAndOpenPDF();
        
        ActionBar actionbar = getActionBar();
		actionbar.setDisplayHomeAsUpEnabled(true);
    }


    void downloadAndOpenPDF() {
        new Thread(new Runnable() {
            public void run() {
                Uri path = Uri.fromFile(downloadFile(download_file_url));
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(path, "application/pdf");
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                } catch (ActivityNotFoundException e) {
                    tv_loading
                            .setError("PDF Reader application is not installed in your device");
                }
            }
        }).start();
    }

    File downloadFile(String dwnload_file_path) {
        File file = null;
        try {
            URL url = new URL(dwnload_file_path);
            HttpURLConnection urlConnection = (HttpURLConnection) url
                    .openConnection(); 
            urlConnection.setRequestMethod("GET");
            urlConnection.setDoOutput(true);
            // connect
            urlConnection.connect(); 
            // set the path where we want to save the file
            File SDCardRoot = Environment.getExternalStorageDirectory();
            // create a new file, to save the downloaded file

            file = new File(SDCardRoot, dest_file_path);
            FileOutputStream fileOutput = new FileOutputStream(file);

            // Stream used for reading the data from the internet

            InputStream inputStream = urlConnection.getInputStream();
            // this is the total size of the file which we are
            // downloading
            totalsize = urlConnection.getContentLength();
            setText("Starting PDF download...");

            // create a buffer...
            byte[] buffer = new byte[1024 * 1024];  
            int bufferLength = 0;
            while ((bufferLength = inputStream.read(buffer)) > 0) {

                fileOutput.write(buffer, 0, bufferLength);

                downloadedSize += bufferLength;

                per = ((float) downloadedSize / totalsize) * 100;

                setText("Total PDF File size  : "

                        + (totalsize / 1024)

                        + " KB\n\nDownloading PDF " + (int) per

                        + "% complete");
            }
            // close the output stream when complete //
            fileOutput.close();
            setText("Download Complete. Open PDF Application installed in the device.");
        } catch (final MalformedURLException e) {
            setTextError("Some error occured. Press back and try again.",
                    Color.RED);
        } catch (final IOException e) {
            setTextError("Some error occured. Press back and try again.",
                    Color.RED);
        } catch (final Exception e) {
            setTextError(
                    "Failed to download image. Please check your internet connection.",
                    Color.RED);
        }

        return file;
    }
    void setTextError(final String message, final int color) {
        runOnUiThread(new Runnable() {
            public void run() {
                tv_loading.setTextColor(color);
                tv_loading.setText(message);
            }

        });

    }
    void setText(final String txt) {

        runOnUiThread(new Runnable() {

            public void run() {

                tv_loading.setText(txt);

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) { 
        super.onCreateOptionsMenu(menu);
    	MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.activity_main, menu);
       // setMenuBackground();
        return true;
        
    }

	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
	
	        switch(item.getItemId()){
	        
	        case android.R.id.home:
	        	finish();
	        	break;
	        
	        case R.id.about:
		
		    Intent a = new Intent(Magazine.this, AboutLWSAT.class);
		    startActivity(a);
		    break; 
		    
	        case R.id.social:		        	
	        	final CharSequence[] items = {"Yookos", "Facebook", "Twitter"};
				 
	        	//Prepare the list dialog box
	        	AlertDialog.Builder builder = new AlertDialog.Builder(this);

	        	//Set its title
	        	builder.setTitle("LoveWorldSAT Socials");

	        	//Set the list items and assign with the click listener
	        	builder.setItems(items, new DialogInterface.OnClickListener() {

	        	// Click listener
	            public void onClick(DialogInterface dialog, int items) {

	            switch (items){
	            	
	        	case 0:
		            Intent de = new Intent(Magazine.this, SATYookos.class);
		          	startActivity(de);
		            break;                   	
		                   	
		            case 1:
		            Intent mg = new Intent(Magazine.this, SATFacebook.class);
		           	startActivity(mg);
		            break;  	
		            
		            case 2:
		            Intent so = new Intent(Magazine.this, SATTwitter.class);
		           	startActivity(so);
		            break;  	
		            
	            
}
}

});

	           	AlertDialog alert = builder.create();

	           	//display dialog box

	            alert.show();     
			  break;
		 		        	
              case R.id.itestify:
		      Intent b = new Intent(Magazine.this, Itestify.class);
		      startActivity(b);	    	
		      break;
		
              case R.id.contact:
	    	  Intent cc = new Intent(Magazine.this, Contact.class);
	    	  startActivity(cc);	
		
		      break;			
	          case R.id.feedback:
	    	  Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
	    	  
		      emailIntent.setType("plain/text");
		      emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"loveworldsat@loveworldmail.org.za"});
		      emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
	    	  emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "");
		
	    	  /* Send it off to the Activity-Chooser */
		     startActivity(Intent.createChooser(emailIntent, "Send mail..."));
		     //finish();
		      break;
		     
             case R.id.share:
	         Intent sharingIntenta = new Intent(Intent.ACTION_SEND);		   
		     sharingIntenta.setType("text/plain");			
		     sharingIntenta.putExtra(android.content.Intent.EXTRA_SUBJECT,"LoveWorldSAT Mobile App");
    	     sharingIntenta.putExtra(android.content.Intent.EXTRA_TEXT, "This is introducing the LoveWorldSAT Mobile Android App! Download now from the Google Play Store: http://bit.ly/lwsatand ");
		     startActivity(Intent.createChooser(sharingIntenta,"Share using"));  

		      break;
	          case R.id.iwitness:
	          Intent iw = new Intent(Magazine.this, Iwitness.class);
	   	      startActivity(iw);
		      break;
		      
	          case R.id.extras:
	   	      final CharSequence[] items1 = {"Decoder Settings", "LoveWorldSAT Magazine"};

        	  //Prepare the list dialog box
        	  AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

        	  //Set its title
        	  builder1.setTitle("Extras");

        	  //Set the list items and assign with the click listener
        	  builder1.setItems(items1, new DialogInterface.OnClickListener() {

        	  // Click listener
              public void onClick(DialogInterface dialog, int items) {

              switch (items){
            	
            	case 0:
                Intent de = new Intent(Magazine.this, DecoderSetting.class);
                startActivity(de);
                break;                   	
                   	
                case 1:
                Intent g = new Intent(Magazine.this, Magazine.class);
           		startActivity(g);
                break;  	
}

}

});
           	    AlertDialog alert1 = builder1.create();

            	//display dialog box 

                alert1.show();     
		        break; 		
}
	            return false;
}
                @Override
 
                public void onConfigurationChanged(Configuration newConfig) {
                super.onConfigurationChanged(newConfig);
                getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

}



}