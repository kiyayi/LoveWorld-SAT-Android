package com.loveworldsat.app;

import com.actionbarsherlock.app.SherlockActivity;

import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class Feedback extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_feedback);
	    
		ActionBar actionbar = getActionBar();
		actionbar.setDisplayHomeAsUpEnabled(true);

	final CharSequence[] items = {"Sms", "Email"};

   	//Prepare the list dialog box
   	AlertDialog.Builder builder = new AlertDialog.Builder(this);

   	//Set its title
   	builder.setTitle("Invite Friends");

   	//Set the list items and assign with the click listener
   	builder.setItems(items, new DialogInterface.OnClickListener() {

   	// Click listener
       public void onClick(DialogInterface dialog, int items) {

       	switch (items){

           case 0:
           	
           	String messageBody = "I would like to invite you to the Higher Life Conference, taking place at the 02 Arena, Peninsula Square,London,from 16th - 18th August, 2013. For details on how to attend, download the HLC United Kingdom Android application from the Google Play Store.Thank You.Sent from HLC Android app";
           		Intent intent = new Intent(Intent.ACTION_VIEW);
           		intent.setData(Uri.parse("sms:"));
           		intent.putExtra( "sms_body", messageBody );
           		startActivity(intent);
           		finish();
           	break;
           case 1:
           	Intent sharingIntent = new Intent(Intent.ACTION_SEND);
       		sharingIntent.setType("text/html");
       		sharingIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String [] {""});
       		sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,"An Invitation To The Higher Life Conference, United Kingdom");
       		sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, Html.fromHtml("<p>Dear Beloved,</p> <p>Warm Greetings,</p> <p>I would like to invite you to the Higher Life Conference, taking place at the 02 Arena, Peninsula Square,London,SE10 the United Kingdom from 16th - 18th August, 2013. For details on how to attend, visit http://higherlifeconferenceuk.com/ or download the HLC United Kingdom Android application from the Google Play Store.</p> <p>Thank You.</p> <p>Sent from HLC Android app</p>"));
       		startActivity(Intent.createChooser(sharingIntent,"Share using"));
       		sharingIntent.setType("message/rfc822");
       	    finish();
           	break;
       	}
   	}

   	});

   	AlertDialog alert = builder.create();

   	//display dialog box

    alert.show();

	}	
	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
	
	        switch(item.getItemId()){
	        
	        case android.R.id.home:
	        	finish();
	        	break;
	        
	        case R.id.about:
		
		    Intent a = new Intent(Feedback.this, AboutLWSAT.class);
		    startActivity(a);
		    break; 
		    
	        case R.id.social:		        	
	        	final CharSequence[] items = {"Yookos", "Facebook", "Twitter"};
				 
	        	//Prepare the list dialog box
	        	AlertDialog.Builder builder = new AlertDialog.Builder(this);

	        	//Set its title
	        	builder.setTitle("LoveWorldSAT Socials");

	        	//Set the list items and assign with the click listener
	        	builder.setItems(items, new DialogInterface.OnClickListener() {

	        	// Click listener
	            public void onClick(DialogInterface dialog, int items) {

	            switch (items){
	            	
	        	case 0:
		            Intent de = new Intent(Feedback.this, SATYookos.class);
		          	startActivity(de);
		            break;                   	
		                   	
		            case 1:
		            Intent mg = new Intent(Feedback.this, SATFacebook.class);
		           	startActivity(mg);
		            break;  	
		            
		            case 2:
		            Intent so = new Intent(Feedback.this, SATTwitter.class);
		           	startActivity(so);
		            break;  	
		            
	            
}
}

});

	           	AlertDialog alert = builder.create();

	           	//display dialog box

	            alert.show();     
			  break;
		 		        	
              case R.id.itestify:
		      Intent b = new Intent(Feedback.this, Itestify.class);
		      startActivity(b);	    	
		      break;
		
              case R.id.contact:
	    	  Intent cc = new Intent(Feedback.this, Contact.class);
	    	  startActivity(cc);	
		
		      break;			
	          case R.id.feedback:
	    	  Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
	    	  
		      emailIntent.setType("plain/text");
		      emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"loveworldsat@loveworldmail.org.za"});
		      emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
	    	  emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "");
		
	    	  /* Send it off to the Activity-Chooser */
		     startActivity(Intent.createChooser(emailIntent, "Send mail..."));
		     //finish();
		      break;
		     
             case R.id.share:
	         Intent sharingIntenta = new Intent(Intent.ACTION_SEND);		   
		     sharingIntenta.setType("text/plain");			
		     sharingIntenta.putExtra(android.content.Intent.EXTRA_SUBJECT,"LoveWorldSAT Mobile App");
    	     sharingIntenta.putExtra(android.content.Intent.EXTRA_TEXT, "This is introducing the LoveWorldSAT Mobile Android App! Download now from the Google Play Store: ");
		     startActivity(Intent.createChooser(sharingIntenta,"Share using"));  

		      break;
	          case R.id.iwitness:
	          Intent iw = new Intent(Feedback.this, Iwitness.class);
	   	      startActivity(iw);
		      break;
		      
	          case R.id.extras:
	   	      final CharSequence[] items1 = {"Decoder Settings", "LoveWorldSAT Magazine"};

        	  //Prepare the list dialog box
        	  AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

        	  //Set its title
        	  builder1.setTitle("Extras");

        	  //Set the list items and assign with the click listener
        	  builder1.setItems(items1, new DialogInterface.OnClickListener() {

        	  // Click listener
              public void onClick(DialogInterface dialog, int items) {

              switch (items){
            	
            	case 0:
                Intent de = new Intent(Feedback.this, DecoderSetting.class);
                startActivity(de);
                break;                   	
                   	
                case 1:
                Intent g = new Intent(Feedback.this, Magazine.class);
           		startActivity(g);
                break;  	
}

}

});
           	    AlertDialog alert1 = builder1.create();

            	//display dialog box 

                alert1.show();     
		        break; 		
}
	            return false;
}
                @Override
 
                public void onConfigurationChanged(Configuration newConfig) {
                super.onConfigurationChanged(newConfig);
                getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

}
}
