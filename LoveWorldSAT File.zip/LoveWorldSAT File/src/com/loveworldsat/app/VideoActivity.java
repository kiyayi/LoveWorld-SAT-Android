package com.loveworldsat.app;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.loveworldsat.app.R;

import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;


@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class VideoActivity extends Activity{
	  

	   TextView mTextview;
	  
	    static final String KEY_ITEM = "item"; // parent node
		static final String KEY_ID = "id";
		static final String KEY_TITLE = "program_title";
		static final String KEY_DESC = "program_desc";
		static final String KEY_FILE_PATH = "program_file_path";
		static final String KEY_THUMB_URL = "thumbnail_path";
		
		String url;
		ImageView max;

@Override
protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	//requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
	//requestWindowFeature(Window.FEATURE_NO_TITLE);
	//getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    setContentView(R.layout.videoview);
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    
    ActionBar actionbar = getActionBar();
	actionbar.setDisplayHomeAsUpEnabled(true);
    
    max= (ImageView)findViewById (R.id.maximize);
	
    Intent i = getIntent();
    // Receiving the Data
    String title = i.getStringExtra(KEY_TITLE);
    String description =i.getStringExtra(KEY_DESC);
    String video_url = i.getStringExtra(KEY_FILE_PATH); 
    
    // Intent intent = getIntent();
    
    TextView txtTitle = (TextView) findViewById(R.id.tvtitle);
    TextView txtDesc = (TextView) findViewById(R.id.tvdesc);
    VideoView videoView = (VideoView) findViewById(R.id.videoviews);
    MediaController mediaController = new MediaController(this);
    
    
    // Log.e("Second Screen", name + "." + email);

    // Displaying Received data
    txtTitle.setText(title);
    txtDesc.setText(description);
    
   url = getUrlVideoRTSP(video_url);
    
   	
	mediaController.setAnchorView(videoView);
	//URI either from net
	Uri video = Uri.parse(url);
	videoView.setMediaController(mediaController);
	videoView.setVideoURI(video);
	videoView.start();
    
	 
    
   /* mTextview =  (TextView)findViewById(R.id.tvtitle);
    mTextview .setText(getIntent().getStringExtra("KEY_TITLE"));
    
    mTextview =  (TextView)findViewById(R.id.tvdesc);
    mTextview .setText(getIntent().getStringExtra("KEY_DESC"));*/
	
    max.setOnClickListener(new OnClickListener(){

        public void onClick(View v) {
            Intent i = new Intent(VideoActivity.this, FullTVProgView.class);
            i.putExtra("video_url", url );
            startActivity(i);
        }
    });
	
		}
public static String getUrlVideoRTSP(String urlYoutube)
{
    try
    {
        String gdy = "http://gdata.youtube.com/feeds/api/videos/";
        DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        String id = extractYoutubeId(urlYoutube);
        URL url = new URL(gdy + id);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        Document doc = documentBuilder.parse(connection.getInputStream());
        Element el = doc.getDocumentElement();
        NodeList list = el.getElementsByTagName("media:content");///media:content
        String cursor = urlYoutube;
        for (int i = 0; i < list.getLength(); i++)
        {
            Node node = list.item(i);
            if (node != null)
            {
                NamedNodeMap nodeMap = node.getAttributes();
                HashMap<String, String> maps = new HashMap<String, String>();
                for (int j = 0; j < nodeMap.getLength(); j++)
                {
                    Attr att = (Attr) nodeMap.item(j);
                    maps.put(att.getName(), att.getValue());
                }
                if (maps.containsKey("yt:format"))
                {
                    String f = maps.get("yt:format");
                    if (maps.containsKey("url"))
                    {
                        cursor = maps.get("url");
                    }
                    if (f.equals("1"))
                        return cursor;
                }
            }
        }
        return cursor;
    }
    catch (Exception ex)
    {
        Log.e("Get Url Video RTSP Exception======>>", ex.toString());
    }
    return urlYoutube;

}

protected static String extractYoutubeId(String url) throws MalformedURLException
{
    String id = null;
    try
    {
        String query = new URL(url).getQuery();
        if (query != null)
        {
            String[] param = query.split("&");
            for (String row : param)
            {
                String[] param1 = row.split("=");
                if (param1[0].equals("v"))
                {
                    id = param1[1];
                }
            }
        }
        else
        {
            if (url.contains("embed"))
            {
                id = url.substring(url.lastIndexOf("/") + 1);
            }
        }
    }
    catch (Exception ex)
    {
        Log.e("Exception", ex.toString());
    }
    return id;
}
@Override
public boolean onCreateOptionsMenu(Menu menu) { 
    super.onCreateOptionsMenu(menu);
	MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.activity_main, menu);
   // setMenuBackground();
    return true;

    


}

@Override
public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId()){
        
        case android.R.id.home:
        	finish();
        	break;
        
        case R.id.about:
	
	    Intent a = new Intent(VideoActivity.this, AboutLWSAT.class);
	    startActivity(a);
	    break; 
	    
        case R.id.social:		        	
        	final CharSequence[] items = {"Yookos", "Facebook", "Twitter"};
			 
        	//Prepare the list dialog box
        	AlertDialog.Builder builder = new AlertDialog.Builder(this);

        	//Set its title
        	builder.setTitle("LoveWorldSAT Socials");

        	//Set the list items and assign with the click listener
        	builder.setItems(items, new DialogInterface.OnClickListener() {

        	// Click listener
            public void onClick(DialogInterface dialog, int items) {

            switch (items){
            	
        	case 0:
	            Intent de = new Intent(VideoActivity.this, SATYookos.class);
	          	startActivity(de);
	            break;                   	
	                   	
	            case 1:
	            Intent mg = new Intent(VideoActivity.this, SATFacebook.class);
	           	startActivity(mg);
	            break;  	
	            
	            case 2:
	            Intent so = new Intent(VideoActivity.this, SATTwitter.class);
	           	startActivity(so);
	            break;  	
	            
            
}
}

});

           	AlertDialog alert = builder.create();

           	//display dialog box

            alert.show();     
		  break;
	 		        	
          case R.id.itestify:
	      Intent b = new Intent(VideoActivity.this, Itestify.class);
	      startActivity(b);	    	
	      break;
	
          case R.id.contact:
    	  Intent cc = new Intent(VideoActivity.this, Contact.class);
    	  startActivity(cc);	
	
	      break;			
          case R.id.feedback:
    	  Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
    	  
	      emailIntent.setType("plain/text");
	      emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"loveworldsat@loveworldmail.org.za"});
	      emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
    	  emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "");
	
    	  /* Send it off to the Activity-Chooser */
	     startActivity(Intent.createChooser(emailIntent, "Send mail..."));
	     //finish();
	      break;
	     
         case R.id.share:
         Intent sharingIntenta = new Intent(Intent.ACTION_SEND);		   
	     sharingIntenta.setType("text/plain");			
	     sharingIntenta.putExtra(android.content.Intent.EXTRA_SUBJECT,"LoveWorldSAT Mobile App");
	     sharingIntenta.putExtra(android.content.Intent.EXTRA_TEXT, "This is introducing the LoveWorldSAT Mobile Android App! Download now from the Google Play Store: http://bit.ly/lwsatand ");
	     startActivity(Intent.createChooser(sharingIntenta,"Share using"));  

	      break;
          case R.id.iwitness:
          Intent iw = new Intent(VideoActivity.this, Iwitness.class);
   	      startActivity(iw);
	      break;
	      
          case R.id.extras:
   	      final CharSequence[] items1 = {"Decoder Settings", "LoveWorldSAT Magazine"};

    	  //Prepare the list dialog box
    	  AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

    	  //Set its title
    	  builder1.setTitle("Extras");

    	  //Set the list items and assign with the click listener
    	  builder1.setItems(items1, new DialogInterface.OnClickListener() {

    	  // Click listener
          public void onClick(DialogInterface dialog, int items) {

          switch (items){
        	
        	case 0:
            Intent de = new Intent(VideoActivity.this, DecoderSetting.class);
            startActivity(de);
            break;                   	
               	
            case 1:
            Intent g = new Intent(VideoActivity.this, Magazine.class);
       		startActivity(g);
            break;  	
}

}

});
       	    AlertDialog alert1 = builder1.create();

        	//display dialog box 

            alert1.show();     
	        break; 		
}
            return false;
}
            @Override

            public void onConfigurationChanged(Configuration newConfig) {
            super.onConfigurationChanged(newConfig);
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

}
}



