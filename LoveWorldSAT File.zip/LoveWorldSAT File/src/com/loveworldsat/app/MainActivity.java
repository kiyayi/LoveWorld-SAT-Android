package com.loveworldsat.app;


import android.os.Bundle;
import android.app.AlertDialog;
import android.app.TabActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;

import com.loveworldsat.app.AppRater;
import com.loveworldsat.app.R;


public class MainActivity extends TabActivity {
	  
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
                 super.onCreate(savedInstanceState);
                 setContentView(R.layout.activity_main);
		         setTabs() ;
		         
		       //Rate this App class
		         AppRater.app_launched(this);
}
	private void setTabs()
{
		       addTab("", R.drawable.tab_search, ArrowsActivity.class);		       
		       addTab("", R.drawable.tab_home, OptionsActivity.class);
		       addTab("", R.drawable.xtianliving, ChristianLiving.class);
		       addTab("", R.drawable.tab_partner, Partnership.class);
		       addTab("", R.drawable.tab_yookos, Yookos.class);
		      // addTab("", R.drawable.xtianliving, ChristianLiving.class);		
		       //addTab("", R.drawable.tab_home, ArrowsActivity.class);
		       //addTab("", R.drawable.tab_search, OptionsActivity.class);
}	
	private void addTab(String labelId, int drawableId, Class<?> c)
{
    @SuppressWarnings("deprecation")
		       TabHost tabHost = getTabHost();
		       Intent intent = new Intent(this, c);
		       TabHost.TabSpec spec = tabHost.newTabSpec("tab" + labelId);	
		
	@SuppressWarnings("deprecation")
	View tabIndicator = LayoutInflater.from(this).inflate(R.layout.tab_indicator, getTabWidget(), false);
		       TextView title = (TextView) tabIndicator.findViewById(R.id.title);
		       title.setText(labelId);
		       ImageView icon = (ImageView) tabIndicator.findViewById(R.id.icon);
		       icon.setImageResource(drawableId);
		
		       spec.setIndicator(tabIndicator);
		       spec.setContent(intent);
		       tabHost.addTab(spec);
}

	   @Override
        public boolean onCreateOptionsMenu(Menu menu) { 
                super.onCreateOptionsMenu(menu);
    	        MenuInflater inflater = getMenuInflater();
                inflater.inflate(R.menu.activity_main, menu);
                // setMenuBackground();
                return true;
        
}

	   @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
		     
		        switch(item.getItemId()){
		        case R.id.about:
			
			    Intent a = new Intent(MainActivity.this, AboutLWSAT.class);
			    startActivity(a);
			    break; 
			    
		        case R.id.social:		        	
		        	final CharSequence[] items = {"Yookos", "Facebook", "Twitter"};
					 
		        	//Prepare the list dialog box
		        	AlertDialog.Builder builder = new AlertDialog.Builder(this);

		        	//Set its title
		        	builder.setTitle("LoveWorldSAT Socials");

		        	//Set the list items and assign with the click listener
		        	builder.setItems(items, new DialogInterface.OnClickListener() {

		        	// Click listener
		            public void onClick(DialogInterface dialog, int items) {

		            switch (items){
		            	
		           	case 0:
		            Intent de = new Intent(MainActivity.this, SATYookos.class);
		          	startActivity(de);
		            break;                   	
		                   	
		            case 1:
		            Intent mg = new Intent(MainActivity.this, SATFacebook.class);
		           	startActivity(mg);
		            break;  	
		            
		            case 2:
		            Intent so = new Intent(MainActivity.this, SATTwitter.class);
		           	startActivity(so);
		            break;  	
		            
}
}

});

		           	AlertDialog alert = builder.create();

		           	//display dialog box

		            alert.show();     
				  break;
			 		        	
	              case R.id.itestify:
			      Intent b = new Intent(MainActivity.this, Itestify.class);
			      startActivity(b);	    	
			      break;
			
	              case R.id.contact:
		    	  Intent cc = new Intent(MainActivity.this, Contact.class);
		    	  startActivity(cc);	
			
			      break;			
		          case R.id.feedback:
		    	  Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
		    	  
			      emailIntent.setType("plain/text");
			      emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"loveworldsat@loveworldmail.org.za"});
			      emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
		    	  emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "");
			
		    	  /* Send it off to the Activity-Chooser */
			     startActivity(Intent.createChooser(emailIntent, "Send mail..."));
			     //finish();
			      break;
			     
	             case R.id.share:
		         Intent sharingIntenta = new Intent(Intent.ACTION_SEND);		   
			     sharingIntenta.setType("text/plain");			
			     sharingIntenta.putExtra(android.content.Intent.EXTRA_SUBJECT,"LoveWorldSAT Mobile App");
	    	     sharingIntenta.putExtra(android.content.Intent.EXTRA_TEXT, "This is introducing the LoveWorldSAT Mobile Android App! Download now from the Google Play Store: http://bit.ly/lwsatand");
			     startActivity(Intent.createChooser(sharingIntenta,"Share using"));  

			      break;
		          case R.id.iwitness:
		          Intent iw = new Intent(MainActivity.this, Iwitness.class);
		   	      startActivity(iw);
			      break;
			      
		          case R.id.extras:
		   	      final CharSequence[] items1 = {"Decoder Settings", "LoveWorldSAT Magazine"};

	        	  //Prepare the list dialog box
	        	  AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

	        	  //Set its title
	        	  builder1.setTitle("Extras");

	        	  //Set the list items and assign with the click listener
	        	  builder1.setItems(items1, new DialogInterface.OnClickListener() {

	        	  // Click listener
	              public void onClick(DialogInterface dialog, int items) {

	              switch (items){
	            	
	            	case 0:
	                Intent de = new Intent(MainActivity.this, DecoderSetting.class);
	                startActivity(de);
	                break;                   	
	                   	
	                case 1:
	                Intent g = new Intent(MainActivity.this, Magazine.class);
	           		startActivity(g);
	                break;  	
}

}

});
	           	    AlertDialog alert1 = builder1.create();

	            	//display dialog box 

	                alert1.show();     
			        break; 		
}
		            return false;
}
                    @Override
     
                    public void onConfigurationChanged(Configuration newConfig) {
                    super.onConfigurationChanged(newConfig);
                    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    
}
}
