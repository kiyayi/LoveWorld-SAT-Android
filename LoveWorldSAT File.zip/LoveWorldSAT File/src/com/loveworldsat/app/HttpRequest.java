package com.loveworldsat.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;

import android.util.Log;

/**
 * HttpRequest This class handles POST and GET requests and enables you to
 * upload files via post. Cookies are stored in the HttpClient.
 * 
 * @author Sander Borgman
 * @url http://www.sanderborgman.nl
 * @version 1
 */
public class HttpRequest {

	/**
	 * GET request
	 * 
	 * @param client
	 * @param url
	 * @return
	 * @throws Exception
	 */
	public static HttpData getRequest(final HttpClient client, final String url)
			throws Exception {

		/**
		 * Setup
		 */
		final HttpData httpData = new HttpData();
		final HttpGet httpGet = new HttpGet(url);

		/**
		 * Run request
		 */
		final HttpResponse response = client.execute(httpGet);
		httpData.data = HttpRequest.GetText(response);
		httpData.response = response;

		/**
		 * Return data
		 */
		return httpData;

	}

	/*
	 * get data as string
	 */

	public static String getData(final HttpPost httpost) throws IOException,
			URISyntaxException {

		String inputLine = "Error";
		final StringBuffer buf = new StringBuffer();

		{

			InputStream ins = null;

			ins = HttpRequest.getUrlData(httpost);

			final InputStreamReader isr = new InputStreamReader(ins);
			final BufferedReader in = new BufferedReader(isr);

			while ((inputLine = in.readLine()) != null) {
				buf.append(inputLine);
			}

			in.close();

		}

		return buf.toString();

	}

	/*
	 * get input stream
	 */
	public static InputStream getUrlData(final HttpPost httpost)
			throws URISyntaxException, ClientProtocolException, IOException {

		final HttpClient client = HttpRequest.getClient();

		final HttpResponse res = client.execute(httpost);

		System.out.println("Login form get: " + res.getStatusLine());

		System.out.println("get login cookies:");
		final List<Cookie> cookies = ((DefaultHttpClient) client)
				.getCookieStore().getCookies();

		if (cookies.isEmpty()) {
			System.out.println("None");
		} else {

			// CurrentData.setCookies(cookies);

			System.out.println("size of cokies " + cookies.size());

			for (int i = 0; i < cookies.size(); i++) {
				Log.e("- " + cookies.get(i).toString(), "");
			}
		}

		// Log.w("response",res.g)

		return res.getEntity().getContent();
	}

	/*
	 * get https client
	 */
	public static DefaultHttpClient getClient() {
		DefaultHttpClient ret = null;
		// sets up parameters
		final HttpParams params = new BasicHttpParams();

		HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
		HttpProtocolParams.setContentCharset(params, "utf-8");
		params.setBooleanParameter("http.protocol.expect-continue", false);
		// registers schemes for both http and https
		final SchemeRegistry registry = new SchemeRegistry();
		registry.register(new Scheme("http", PlainSocketFactory
				.getSocketFactory(), 80));
		final SSLSocketFactory sslSocketFactory = SSLSocketFactory
				.getSocketFactory();
		sslSocketFactory
				.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
		registry.register(new Scheme("https", sslSocketFactory, 443));
		final ThreadSafeClientConnManager manager = new ThreadSafeClientConnManager(
				params, registry);
		ret = new DefaultHttpClient(manager, params);
		return ret;

	}

	/*
	 * get inputstream for get request
	 */

	public static InputStream getInputStreamForGetRequest(final String url) {
		final DefaultHttpClient httpClient = HttpRequest.getClient();
		URI uri;
		InputStream data = null;
		try {
			uri = new URI(url);
			final HttpGet method = new HttpGet(uri);
			final HttpResponse response = httpClient.execute(method);
			final String code = response.getStatusLine().toString();
			Log.w("status line ", code);
			data = response.getEntity().getContent();
		} catch (final Exception e) {
			e.printStackTrace();
		}

		return data;
	}

	/**
	 * Get string from stream
	 * 
	 * @param InputStream
	 * @return
	 */
	public static String GetText(final InputStream in) {
		String text = "";
		final BufferedReader reader = new BufferedReader(new InputStreamReader(
				in));
		final StringBuilder sb = new StringBuilder();
		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			text = sb.toString();
		} catch (final Exception ex) {

		} finally {
			try {
				in.close();
			} catch (final Exception ex) {
			}
		}
		return text;
	}

	/**
	 * Get string from stream
	 * 
	 * @param HttpResponse
	 * @return
	 */
	private static String GetText(final HttpResponse response) {
		String text = "";
		try {
			text = HttpRequest.GetText(response.getEntity().getContent());
		} catch (final Exception ex) {
		}
		return text;
	}

}
