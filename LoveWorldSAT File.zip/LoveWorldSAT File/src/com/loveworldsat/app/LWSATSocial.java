package com.loveworldsat.app;


	import android.os.Bundle;
	import android.app.Activity;
	import android.app.AlertDialog;
	import android.content.DialogInterface;
	import android.content.Intent;
	import android.text.Html;
	import android.view.Menu;
	import android.view.MenuItem;
    import android.view.View.OnClickListener;

	public class LWSATSocial extends Activity {

		 public void onCreate(Bundle savedInstanceState) {
		        super.onCreate(savedInstanceState);
		      // setContentView(R.layout.activity_main);			
		 
			 final CharSequence[] items = {"Yookos", "Facebook", "Twitter"};
			 
	        	//Prepare the list dialog box
	        	AlertDialog.Builder builder = new AlertDialog.Builder(this);

	        	//Set its title
	        	builder.setTitle("LoveWorldSAT Socials");

	        	//Set the list items and assign with the click listener
	        	builder.setItems(items, new DialogInterface.OnClickListener() {

	        	// Click listener
	            public void onClick(DialogInterface dialog, int items) {

	            	switch (items){
	            	
	            	case 0:
	            		 Intent de = new Intent(LWSATSocial.this, SATYookos.class);
	            			startActivity(de);
	                   	break;                   	
	                   	
	                   case 1:
	                	   Intent mg = new Intent(LWSATSocial.this, SATTwitter.class);
	           			startActivity(mg);
	                 break;  	
	                   case 2:
	                	   Intent so = new Intent(LWSATSocial.this, SATFacebook.class);
	           			startActivity(so);
	                 break;  	
	             	}
	           	}

	           	});

	           	AlertDialog alert = builder.create();

	           	//display dialog box

	            alert.show();     
			
		 }
		
	}


	