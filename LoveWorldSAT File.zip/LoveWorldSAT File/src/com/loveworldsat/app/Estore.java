package com.loveworldsat.app;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Window;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.loveworldsat.app.R;

@SuppressLint("NewApi")
public class Estore extends Activity {

	WebView html;

	@TargetApi(11)
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
		setContentView(R.layout.activity_estore);
		getActionBar().setDisplayHomeAsUpEnabled(true);

		/*
		 * public void onClick(View view) { Intent myIntent = new Intent(a,
		 * Estore.class); myIntent.putExtra("url",
		 * "http://christembassydigitalmedia.com"); myIntent.putExtra("title",
		 * "Online Store"); a.startActivity(myIntent);
		 * 
		 * }
		 */
		html = (WebView) findViewById(R.id.esBrowser);
		html.loadUrl("http://christembassydigitalmedia.com/digital");
		html.setWebViewClient(new WebViewClient());
		html.getSettings().setUseWideViewPort(true);
		// html.getSettings().setLoadWithOverviewMode(true);
		html.getSettings().setJavaScriptEnabled(true);
		{

			html.setWebViewClient(new WebViewClient() {
				@Override
				public boolean shouldOverrideUrlLoading(WebView view, String url) {
					return false;
				}

				@Override
				public void onPageStarted(WebView view, String url,
						Bitmap favicon) {
					super.onPageStarted(view, url, favicon);

					setProgressBarIndeterminateVisibility(true);
				}

				@Override
				public void onPageFinished(WebView view, String url) {

					if (isOnline()) {
						setProgressBarIndeterminateVisibility(false);
					} else {
						AlertDialog NetAlert = new AlertDialog.Builder(
								Estore.this).create();
						NetAlert.setMessage("No internet connection found. Please check your connection and try again!");
						NetAlert.setButton("OK",
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int which) {

										// here you can add functions
										finish();

									}
								});
						NetAlert.show();

						setProgressBarIndeterminateVisibility(false);
					}
				}

				public void onReceivedError(WebView view, int errorCode,
						String description, String failingUrl) {
					html.loadUrl("file:///android_asset/internet.htm");
				}

				public boolean isOnline() {
					ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
					NetworkInfo ni = cm.getActiveNetworkInfo();

					if (ni != null && ni.isConnectedOrConnecting()) {
						return true;
					} else {
						return false;
					}

				}
			});
		}
	}

	public void onReceivedError(WebView view, int errorCode,
			String description, String failingUrl) {
		html.loadUrl("file:///android_asset/internet.htm");

	}

	public boolean isOnline() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo ni = cm.getActiveNetworkInfo();

		if (isOnline()) {
			// my code
		} else {
			Estore.this.startActivity(new Intent(
					Settings.ACTION_WIRELESS_SETTINGS));
			try {
				AlertDialog alertDialog = new AlertDialog.Builder(Estore.this)
						.create();

				alertDialog.setTitle("Info");
				alertDialog
						.setMessage("Internet not available, Cross check your internet connectivity and try again");
				// alertDialog.setIcon(R.drawable.alerticon);
				alertDialog.setButton("OK",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								finish();

							}
						});

				alertDialog.show();
			} catch (Exception e) {
				// Log.d(Constants.TAG, "Show Dialog: "+e.getMessage());
			}
		}
		return false;
	}

}
