package com.loveworldsat.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;


import com.loveworldsat.app.AboutLWSAT;
import com.loveworldsat.app.Itestify;
import com.loveworldsat.app.Feedback;
import com.loveworldsat.app.Schedule;
import com.loveworldsat.app.Shareapp;
import com.loveworldsat.app.Iwitness;
import com.loveworldsat.app.Extras;


public class ActionBarMenu {

	Context a;
	public ActionBarMenu (){
		//TODO
	}
	public ActionBarMenu(Activity a){
		this.a = a;
	}
	
	public void showAbout(){
		//TODO
		Intent mIntent = new Intent(a, AboutLWSAT.class);
		a.startActivity(mIntent);
	}	
	public void showItestify(){
		//TODO		
		Intent myIntent = new Intent(a, Itestify.class);
		a.startActivity(myIntent);
	}
	public void showFeedback() {
		// TODO Auto-generated method stub
		Intent mIntent = new Intent(a,Feedback.class);
		a.startActivity(mIntent);
	}	
	public void showSchedule() {
		// TODO Auto-generated method stub
		Intent mIntent = new Intent(a,Schedule.class);
		a.startActivity(mIntent);
	}
	
	public void showShareapp(){
		//TODO
		Intent mIntent = new Intent(a, Shareapp.class);
		a.startActivity(mIntent);
	}
	
	public void showIwitness() {
		// TODO Auto-generated method stub
		Intent mIntent = new Intent(a, Iwitness.class);
		a.startActivity(mIntent);
	}
	public void showExtras() {
		// TODO Auto-generated method stub
		Intent mIntent = new Intent(a, Extras.class);
		a.startActivity(mIntent);
	}
}
	