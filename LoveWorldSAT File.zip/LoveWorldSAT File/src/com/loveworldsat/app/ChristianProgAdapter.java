package com.loveworldsat.app;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;



public class ChristianProgAdapter extends BaseAdapter {
    
    private Activity activity;
    private ArrayList<HashMap<String, String>> data;
    private static LayoutInflater inflater=null;
    public ImageLoader imageLoader; 
    
    static final String KEY_ITEM = "item"; // parent node
  	static final String KEY_ID = "id";
  	static final String VID_TITLE = "video_title";
  	static final String VID_AUTHOR = "vid_author";
  	static final String VID_FILE_PATH = "video_file_path";
  	static final String VID_THUMB = "vid_thumbpath";
  	static final String VID_TIME = "vid_time";
    
    public ChristianProgAdapter(Activity a, ArrayList<HashMap<String, String>> d) {
        activity = a;
        data=d;
        inflater = (LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        imageLoader=new ImageLoader(activity.getApplicationContext());
    }

    public int getCount() {
        return data.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }
    
   
    public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
    	HashMap<String, String> current = data.get(position);
    	
    	Intent in = new Intent(activity, XLivingVideoActivity.class);
   	    in.putExtra(VID_TITLE, current.get(VID_TITLE));
        in.putExtra(VID_AUTHOR, current.get(VID_AUTHOR));
        in.putExtra(VID_FILE_PATH, current.get(VID_FILE_PATH));
         
        // in.putExtra(KEY_THUMB_URL, thumbnail_path);
         activity.startActivity(in);  
		
    }
    
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi=convertView;
        if(convertView==null)
            vi = inflater.inflate(R.layout.list_rows, null);

       TextView program_title = (TextView)vi.findViewById(R.id.program_name); // title
       TextView program_desc = (TextView)vi.findViewById(R.id.program_content); // artist name
       //TextView duration = (TextView)vi.findViewById(R.id.duration); // duration
       ImageView program_file_thumbnail_path=(ImageView)vi.findViewById(R.id.id_prog_thumbnail); // thumb image
        
        HashMap<String, String> song = new HashMap<String, String>();
        song = data.get(position);
        
      // Setting all values in listview
      program_title.setText(song.get(ChristianLiving.VID_TITLE));
       program_desc.setText(song.get(ChristianLiving.VID_AUTHOR));
      // duration.setText(song.get(OptionsActivity.KEY_DURATION));
        imageLoader.DisplayImage(song.get(ChristianLiving.VID_THUMB), program_file_thumbnail_path);
        return vi;
    }
}