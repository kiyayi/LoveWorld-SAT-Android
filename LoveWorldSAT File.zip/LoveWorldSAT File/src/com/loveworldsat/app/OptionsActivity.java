package com.loveworldsat.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import com.loveworldsat.app.R;

import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.StrictMode;
import android.widget.AdapterView.OnItemClickListener;
import java.net.URL;

@SuppressLint("NewApi")
public class OptionsActivity extends Activity {
	
	
private static final String TAG = "OptionsActivity";
	
	
	
	// All static variables
	static final String URL = "http://videoshare.loveworldapis.com/lw_music/tvprograms.xml";
	// XML node keys  
	static final String KEY_ITEM = "item"; // parent node
	static final String KEY_ID = "id";
	static final String KEY_TITLE = "program_title";
	static final String KEY_DESC = "program_desc";
	static final String KEY_FILE_PATH = "program_file_path";
	static final String KEY_THUMB_URL = "thumbnail_path";

	

	ListView list;
    LazyAdapter adapter;
    TextView txttitle;
    TextView txtdesc;
    
    Document doc;
    XMLParser parser;
    String xml;
    
    //ImageView program_file_thumbnail_path;
    
    //String vidid, prgtitle, prgdesc, vidpath,vidthumbpath;

	 
	@Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.optionspage);
	        

	        if (!checkInternetConnection()){
	        	//Write toast or dialog
	        	AlertDialog alertDialog = new AlertDialog.Builder(OptionsActivity.this).create();

			    // Setting Dialog Title
			    alertDialog.setTitle("No Connection!");
			
				    // Setting Dialog Message
				alertDialog.setMessage("No internet conection, please check your internet connection before trying again!");
				
				    // Setting Icon to Dialog
				    //alertDialog.setIcon(R.drawable.ok);
				
				    // Setting OK Button
				alertDialog.setButton(DialogInterface.BUTTON_POSITIVE,"Exit", new DialogInterface.OnClickListener() {
				            public void onClick(DialogInterface dialog, int which) {
				            // Write your code here to execute after dialog closed
				           // Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
				            	finish();
				            }
				    });

			    	// Showing Alert Message
			    alertDialog.show();
	        }
	        
	        else{
	        	 
	            
	           // this allow the passing of a thread called the strict mode thread policy
	            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

	            StrictMode.setThreadPolicy(policy);
	            
	            final ArrayList<HashMap<String, String>> songsList = new ArrayList<HashMap<String, String>>();

	    		parser = new XMLParser();
				try {
					xml = parser.getXmlFromUrl(URL);
					doc = parser.getDomElement(xml);
				} catch (IOException e) {
					AlertDialog alertDialog = new AlertDialog.Builder(OptionsActivity.this).create();

				    // Setting Dialog Title
				    alertDialog.setTitle("Connection Failed!");
					alertDialog.setMessage("Error in Connection. Please try again.");
					alertDialog.setButton(DialogInterface.BUTTON_POSITIVE,"Exit", new DialogInterface.OnClickListener() {
					            public void onClick(DialogInterface dialog, int which) {
					            // Write your code here to execute after dialog closed
					           // Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
					            	finish();
					            }
					    });
				    alertDialog.show();
				}
				catch(NullPointerException ne){
					AlertDialog alertDialog = new AlertDialog.Builder(OptionsActivity.this).create();
					// Setting Dialog Title
				    alertDialog.setTitle("Connection Failed!");
					alertDialog.setMessage("Error in Connection. Please try again.");
					alertDialog.setButton(DialogInterface.BUTTON_POSITIVE,"Exit", new DialogInterface.OnClickListener() {
					            public void onClick(DialogInterface dialog, int which) {
					            // Write your code here to execute after dialog closed
					           // Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
					            	finish();
					            }
					    });
				    alertDialog.show();
				}
				
				 // getting DOM element
	    		NodeList nl = doc.getElementsByTagName(KEY_ITEM);
	    		// looping through all song nodes <song>
	    		for (int i = 0; i < nl.getLength(); i++) {
	    			
	    			// creating new HashMap
	    			HashMap<String, String> map = new HashMap<String, String>();
	    			Element e = (Element) nl.item(i);
	    			//add content of the element to a variable
	    			map.put(KEY_ID,parser.getValue(e, KEY_ID));
	    			map.put(KEY_FILE_PATH,parser.getValue(e, KEY_FILE_PATH));
	    			map.put(KEY_TITLE,parser.getValue(e,KEY_TITLE));
	    			map.put(KEY_DESC,parser.getValue(e, KEY_DESC));
	    			map.put(KEY_THUMB_URL,parser.getValue(e, KEY_THUMB_URL));
	    			//Toast.makeText(getApplicationContext(), id, 1).show();
	    			
	    		
	    			
	    			// adding HashList to ArrayList
	    			songsList.add(map);
	    		}
	    		

	    		list = (ListView)findViewById(R.id.list);

	    		
	    		// Getting adapter by passing xml data ArrayList
	            adapter = new LazyAdapter(this, songsList);        
	            list.setAdapter(adapter);
	            
	            list.setOnItemClickListener(new OnItemClickListener(){
					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1,
							int position, long arg3) {
						HashMap<String, String> current = songsList.get(position);
						
						Intent in = new Intent(OptionsActivity.this, VideoActivity.class);
				         in.putExtra(KEY_TITLE, current.get(KEY_TITLE));
				         in.putExtra(KEY_DESC, current.get(KEY_DESC));
				         in.putExtra(KEY_FILE_PATH, current.get(KEY_FILE_PATH));
				         
				        // in.putExtra(KEY_THUMB_URL, thumbnail_path);
				         startActivity(in);  
					}

	            });
	        }
	            
	 }
	
	
	           
	  // this code detect the network state of the application, this checks if there is network or not 
	       private boolean checkInternetConnection() {

	    	   ConnectivityManager conMgr = (ConnectivityManager) getSystemService (Context.CONNECTIVITY_SERVICE);

	    	   // ARE WE CONNECTED TO THE NET

	    	   if (conMgr.getActiveNetworkInfo() != null && conMgr.getActiveNetworkInfo().isAvailable() && conMgr.getActiveNetworkInfo().isConnected()) {

	    		   return true;

	    	   } else {
	
		    	   Log.v(TAG, "Internet Connection Not Present");
	
		    	   return false;

	    	   }

	    } 
	 
	 @Override
	        public boolean onCreateOptionsMenu(Menu menu) { 
	            super.onCreateOptionsMenu(menu);	        	
	            return true;
	            
	        }
	 
	private static String extractYoutubeId(String urlYoutube) {
		// TODO Auto-generated method stub
		return null;
	}


}
	        
