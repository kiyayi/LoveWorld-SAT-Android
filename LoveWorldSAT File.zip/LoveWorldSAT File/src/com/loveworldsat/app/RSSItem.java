package com.loveworldsat.app;

public class RSSItem {
    public String title;
    public String date;
    public String link;
    public String description;
}

