package com.loveworldsat.app;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import com.loveworldsat.app.R;

import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.os.StrictMode;
import android.widget.AdapterView.OnItemClickListener;
import java.net.URL;

@SuppressLint("NewApi")
public class ChristianLiving extends Activity {
	
	
private static final String TAG = "ChristianLiving";
	
	
	
	// All static variables
	static final String URL = "http://videoshare.loveworldapis.com/lw_music/feed/christianliving/";
	// XML node keys  
	static final String KEY_ITEM = "item"; // parent node
	static final String KEY_ID = "id";
	static final String VID_TITLE = "video_title";
	static final String VID_AUTHOR = "vid_author";
	static final String VID_FILE_PATH = "video_file_path";
	static final String VID_THUMB = "vid_thumbpath";
	static final String VID_TIME = "vid_time";
	

	ListView list;
    ChristianProgAdapter adapter;
    TextView txttitle;
    TextView tvauthor;
    
    Document doc;
    XMLParser parser;
    String xml;
	 
	@Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.christianliving);
	        
	     

	        if (!checkInternetConnection()){
	        	//Write toast or dialog
	        	AlertDialog alertDialog = new AlertDialog.Builder(ChristianLiving.this).create();

			    // Setting Dialog Title
			    alertDialog.setTitle("No Connection!");
			
				    // Setting Dialog Message
				    alertDialog.setMessage("No internet conection, please check your internet connection before trying again!");
				
				    // Setting Icon to Dialog
				    //alertDialog.setIcon(R.drawable.ok);
				
				    // Setting OK Button
				    alertDialog.setButton(DialogInterface.BUTTON_POSITIVE,"Exit", new DialogInterface.OnClickListener() {
				            public void onClick(DialogInterface dialog, int which) {
				            // Write your code here to execute after dialog closed
				           // Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
				            	finish();
				            }
				    });

			    	// Showing Alert Message
			    	alertDialog.show();
	        }
	        
	        else{
	        	 
	            
	           // this allow the passing of a thread called the strict mode thread policy
	            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

	            StrictMode.setThreadPolicy(policy);
	            
	            final ArrayList<HashMap<String, String>> songsList = new ArrayList<HashMap<String, String>>();

	    		parser = new XMLParser();
				try {
					xml = parser.getXmlFromUrl(URL);
					doc = parser.getDomElement(xml);
				} catch (IOException e) {
					AlertDialog alertDialog = new AlertDialog.Builder(ChristianLiving.this).create();

				    // Setting Dialog Title
				    alertDialog.setTitle("Connection Failed!");
					alertDialog.setMessage("Error in Connection. Please try again.");
					alertDialog.setButton(DialogInterface.BUTTON_POSITIVE,"Exit", new DialogInterface.OnClickListener() {
					            public void onClick(DialogInterface dialog, int which) {
					            // Write your code here to execute after dialog closed
					           // Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
					            	finish();
					            }
					    }); 
				    alertDialog.show();
				}
				catch(NullPointerException ne){
					AlertDialog alertDialog = new AlertDialog.Builder(ChristianLiving.this).create();
					// Setting Dialog Title
				    alertDialog.setTitle("Connection Failed!");
					alertDialog.setMessage("Error in Connection. Please try again.");
					alertDialog.setButton(DialogInterface.BUTTON_POSITIVE,"Exit", new DialogInterface.OnClickListener() {
					            public void onClick(DialogInterface dialog, int which) {
					            // Write your code here to execute after dialog closed
					           // Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
					            	finish();
					            }
					    });
				    alertDialog.show();
				}
				
				 // getting DOM element
	    		NodeList nl = doc.getElementsByTagName(KEY_ITEM);
	    		// looping through all song nodes <song>
	    		for (int i = 0; i < nl.getLength(); i++) {
	    			
	    			// creating new HashMap
	    			HashMap<String, String> map = new HashMap<String, String>();
	    			Element e = (Element) nl.item(i);
	    			//add content of the element to a variable
	    		
	    			/*String id = parser.getValue(e, KEY_ID).toString();
	    			String vidtitle = parser.getValue(e,VID_TITLE).toString();
	    			String imgthumb = parser.getValue(e, VID_THUMB).toString();
	    			String vidpath = parser.getValue(e, VID_FILE_PATH).toString();
	    			
	    			Toast.makeText(getApplicationContext(), vidpath, 1).show();
	    			Toast.makeText(getApplicationContext(), imgthumb, 1).show();
	    			Toast.makeText(getApplicationContext(), id, Toast.LENGTH_LONG).show();
	    			Toast.makeText(getApplicationContext(), vidtitle, Toast.LENGTH_LONG).show();*/
	    			
	    			map.put(KEY_ID,parser.getValue(e, KEY_ID));
	    			map.put(VID_FILE_PATH,parser.getValue(e, VID_FILE_PATH));
	    			map.put(VID_TITLE,parser.getValue(e,VID_TITLE));
	    			map.put(VID_AUTHOR,parser.getValue(e, VID_AUTHOR));
	    			map.put(VID_THUMB,parser.getValue(e, VID_THUMB));
	    			//Toast.makeText(getApplicationContext(), id, 1).show();
	    			//Toast.makeText(getApplicationContext(), VID_TITLE, 1).show();
	    			// adding HashList to ArrayList
	    			songsList.add(map);
	    		}
	    		list = (ListView)findViewById(R.id.xlivinglist);
	    		
	    		// Getting adapter by passing xml data ArrayList
	            adapter = new ChristianProgAdapter(this, songsList);        
	            list.setAdapter(adapter);
	            
	            list.setOnItemClickListener(new OnItemClickListener(){
					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1,
							int position, long arg3) {
						HashMap<String, String> current = songsList.get(position);
						
						Intent in = new Intent(ChristianLiving.this, XLivingVideoActivity.class);
				         in.putExtra(VID_TITLE, current.get(VID_TITLE));
				         in.putExtra(VID_AUTHOR, current.get(VID_AUTHOR));
				         in.putExtra(VID_FILE_PATH, current.get(VID_FILE_PATH));

				         
				        // in.putExtra(KEY_THUMB_URL, thumbnail_path);
				         startActivity(in);  
					}

	            });
	        }
	            
	 }
	
	
	           
	  // this code detect the network state of the application, this checks if there is network or not 
	       private boolean checkInternetConnection() {

	    	   ConnectivityManager conMgr = (ConnectivityManager) getSystemService (Context.CONNECTIVITY_SERVICE);

	    	   // ARE WE CONNECTED TO THE NET

	    	   if (conMgr.getActiveNetworkInfo() != null && conMgr.getActiveNetworkInfo().isAvailable() && conMgr.getActiveNetworkInfo().isConnected()) {

	    		   return true;

	    	   } else {
	
		    	   Log.v(TAG, "Internet Connection Not Present");
	
		    	   return false;

	    	   }

	    } 
	 
	       @Override
	       public boolean onCreateOptionsMenu(Menu menu) { 
	           super.onCreateOptionsMenu(menu);
	       	MenuInflater inflater = getMenuInflater();
	           inflater.inflate(R.menu.activity_main, menu);
	          // setMenuBackground();
	           return true;
	           
	       }

	   	@Override
	       public boolean onOptionsItemSelected(MenuItem item) {
	   	
	   	        switch(item.getItemId()){
	   	        
	   	        case android.R.id.home:
	   	        	finish();
	   	        	break;
	   	        
	   	        case R.id.about:
	   		
	   		    Intent a = new Intent(ChristianLiving.this, AboutLWSAT.class);
	   		    startActivity(a);
	   		    break; 
	   		    
	   	        case R.id.social:		        	
	   	        	final CharSequence[] items = {"Yookos", "Facebook", "Twitter"};
	   				 
	   	        	//Prepare the list dialog box
	   	        	AlertDialog.Builder builder = new AlertDialog.Builder(this);

	   	        	//Set its title
	   	        	builder.setTitle("LoveWorldSAT Socials");

	   	        	//Set the list items and assign with the click listener
	   	        	builder.setItems(items, new DialogInterface.OnClickListener() {

	   	        	// Click listener
	   	            public void onClick(DialogInterface dialog, int items) {

	   	            switch (items){
	   	            	
	   	        	case 0:
	   		            Intent de = new Intent(ChristianLiving.this, SATYookos.class);
	   		          	startActivity(de);
	   		            break;                   	
	   		                   	
	   		            case 1:
	   		            Intent mg = new Intent(ChristianLiving.this, SATFacebook.class);
	   		           	startActivity(mg);
	   		            break;  	
	   		            
	   		            case 2:
	   		            Intent so = new Intent(ChristianLiving.this, SATTwitter.class);
	   		           	startActivity(so);
	   		            break;  	
	   		            
	   	            
	   }
	   }

	   });

	   	           	AlertDialog alert = builder.create();

	   	           	//display dialog box

	   	            alert.show();     
	   			  break;
	   		 		        	
	                 case R.id.itestify:
	   		      Intent b = new Intent(ChristianLiving.this, Itestify.class);
	   		      startActivity(b);	    	
	   		      break;
	   		
	                 case R.id.contact:
	   	    	  Intent cc = new Intent(ChristianLiving.this, Contact.class);
	   	    	  startActivity(cc);	
	   		
	   		      break;			
	   	          case R.id.feedback:
	   	    	  Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
	   	    	  
	   		      emailIntent.setType("plain/text");
	   		      emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"loveworldsat@loveworldmail.org.za"});
	   		      emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
	   	    	  emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "");
	   		
	   	    	  /* Send it off to the Activity-Chooser */
	   		     startActivity(Intent.createChooser(emailIntent, "Send mail..."));
	   		     //finish();
	   		      break;
	   		     
	                case R.id.share:
	   	         Intent sharingIntenta = new Intent(Intent.ACTION_SEND);		   
	   		     sharingIntenta.setType("text/plain");			
	   		     sharingIntenta.putExtra(android.content.Intent.EXTRA_SUBJECT,"LoveWorldSAT Mobile App");
	       	     sharingIntenta.putExtra(android.content.Intent.EXTRA_TEXT, "This is introducing the LoveWorldSAT Mobile Android App! Download now from the Google Play Store: http://bit.ly/lwsatand ");
	   		     startActivity(Intent.createChooser(sharingIntenta,"Share using"));  

	   		      break;
	   	          case R.id.iwitness:
	   	          Intent iw = new Intent(ChristianLiving.this, Iwitness.class);
	   	   	      startActivity(iw);
	   		      break;
	   		      
	   	          case R.id.extras:
	   	   	      final CharSequence[] items1 = {"Decoder Settings", "LoveWorldSAT Magazine"};

	           	  //Prepare the list dialog box
	           	  AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

	           	  //Set its title
	           	  builder1.setTitle("Extras");

	           	  //Set the list items and assign with the click listener
	           	  builder1.setItems(items1, new DialogInterface.OnClickListener() {

	           	  // Click listener
	                 public void onClick(DialogInterface dialog, int items) {

	                 switch (items){
	               	
	               	case 0:
	                   Intent de = new Intent(ChristianLiving.this, DecoderSetting.class);
	                   startActivity(de);
	                   break;                   	
	                      	
	                   case 1:
	                   Intent g = new Intent(ChristianLiving.this, Magazine.class);
	              		startActivity(g);
	                   break;  	
	   }

	   }

	   });
	              	    AlertDialog alert1 = builder1.create();

	               	//display dialog box 

	                   alert1.show();     
	   		        break; 		
	   }
	   	            return false;
	   }
	                   @Override
	    
	                   public void onConfigurationChanged(Configuration newConfig) {
	                   super.onConfigurationChanged(newConfig);
	                   getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

	   }
	 
	 	 
	private static String extractYoutubeId(String urlYoutube) {
		// TODO Auto-generated method stub
		return null;
	}


}
	        
