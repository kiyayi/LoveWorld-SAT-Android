package com.loveworldsat.app;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.VideoView;


   @TargetApi(9)
   public class ArrowsActivity extends Activity {

    private static final String TAG = "ArrowsActivity";
    private ProgressDialog videoBuffering;

    String name, email,comment, firstValue, secondValue;
    Button yes;
    EditText nameField, emailField, countryField, commentField;
    ImageView refresh;

    Pattern pattern;
    Matcher matcher;
    
    private VideoView vid;
    private static final int LIVE_BLOG = 1;
    private static final int COMMENT = 2;
    private static int FLAG = LIVE_BLOG;

    LinearLayout liveblog_tab;
    LinearLayout addcom_tab;
    LinearLayout liveblog;
    LinearLayout comments; 
  
    String selItem;
    WebView ourBrow;


      private void viewCategory() {


    	  AlertDialog.Builder viewDialog = new AlertDialog.Builder(this);
    	  
    	  viewDialog.setTitle("LoveWorldSAT App");
    	  viewDialog.setIcon(R.drawable.ic_launcher);
    	  LayoutInflater li = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    	  final View dialogView = li.inflate(R.layout.commentlayout, null);
    	  viewDialog.setView(dialogView);
    	  viewDialog.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
    	  
    	  public void onClick(DialogInterface dialog, int whichButton) {
    	               nameField = (EditText) dialogView.findViewById(R.id.editText1);
    	               emailField = (EditText) dialogView.findViewById(R.id.editText2);
    	               commentField = (EditText) dialogView.findViewById(R.id.commentField);
    	               
    	               
    	            //get message from message fields
    	               String  name = nameField.getText().toString();
    	               String  emaila = emailField.getText().toString();
                       String  comm = commentField.getText().toString();
                       if(name.length()>0 && comm.length()>0) {
                    	   if (validateEmailField(emaila)){
                    		   doSubmitComment(name, emaila, comm);
                    	   }
                    	   else{
                    		   Toast.makeText(getApplicationContext(), "The Email Field is Invalid", Toast.LENGTH_LONG).show();
                    	   }
                       }
                       else {
                    	   //display message if text field is empty
                    	   Toast.makeText(getBaseContext(),"All fields are required",Toast.LENGTH_SHORT).show();
                       } 
    	  }

    	  });
    	  
    	  viewDialog.setNegativeButton("Cancel",
    			  new DialogInterface.OnClickListener() {
    		  public void onClick(DialogInterface dialog, int whichButton) {
    		  }
    	  });    
    	  viewDialog.show();
    	  Spinner spinnercategory = (Spinner) dialogView.findViewById(R.id.spinner);
    	  ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.category, android.R.layout.simple_spinner_item);
    	  adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    	  spinnercategory.setAdapter(adapter);
    	  spinnercategory.setOnItemSelectedListener(new OnItemSelectedListener() {
    		  public void onItemSelected(AdapterView<?> parent, View arg1,
    				  int arg2, long arg3) {
    			  selItem = parent.getSelectedItem().toString();

    		  }
    		  public void onNothingSelected(AdapterView<?> arg0) {

    			  // TODO Auto-generated method stub

    		  }

    	  });

      }
      
      private void doSubmitComment(String name, String emaila, String comm){
    	  //check whether the name field is empty or not
          

        	  HttpClient httpclient = new DefaultHttpClient();
        	  HttpPost httppost = new HttpPost("http://videoshare.loveworldapis.com/lwsatapp/post_cmt.php");

        	  try {
        		  List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(3);

        		  // nameValuePairs.add(new BasicNameValuePair("id", "01"));
        		  nameValuePairs.add(new BasicNameValuePair("name", name));
        		  nameValuePairs.add(new BasicNameValuePair("email", emaila));
        		  nameValuePairs.add(new BasicNameValuePair("country", selItem));
        		  nameValuePairs.add(new BasicNameValuePair("comment", comm));
        		  httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));   	              
        		  httpclient.execute(httppost);

        		  nameField.setText(""); //reset the message text field
        		  emailField.setText("");
        		  //countryField.setText("")
        		  commentField.setText("");

        		  Toast.makeText(getBaseContext(),"Sent. Your comment is awaitng approval",Toast.LENGTH_SHORT).show();
        	  } catch (ClientProtocolException e) {
        		  e.printStackTrace();
        	  } catch (IOException e) {
        		  e.printStackTrace();
        	  }   	                               
        	  ourBrow.reload();   
      
      }

      @Override
      protected void onCreate(Bundle savedInstanceState) {
    	  super.onCreate(savedInstanceState);
    	  setContentView(R.layout.arrowspage);
         setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    	  {

    		  
    		  refresh = (ImageView) findViewById(R.id.refresh);

    		  StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    		  StrictMode.setThreadPolicy(policy); 
               
    		  if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.GINGERBREAD) {
    			     // only for gingerbread and newer versions
    			
    		  vid = (VideoView) findViewById(R.id.videoview);
    		  vid.setVideoPath("http://155.obj.netromedia.net/MobileStream/MobileStream/playlist.m3u8");
    		  MediaController mediaController = new MediaController(this);
    		  mediaController.setAnchorView(vid);
    		  //vid.setMediaController(mediaController);
    		  vid.requestFocus();
    		  vid.start();
    		  }
    		  else{
    			  vid = (VideoView) findViewById(R.id.videoview);
        		  vid.setVideoPath("rtsp://155.obj.netromedia.net/MobileStream/MobileStream");
        		  MediaController mediaController = new MediaController(this);
        		  mediaController.setAnchorView(vid);
        		  //vid.setMediaController(mediaController);
        		  vid.requestFocus();
        		  vid.start();
    			  
    		  }


    		  videoBuffering = new ProgressDialog(this);
    		  videoBuffering.setMessage("Loading video data....");
    		  videoBuffering.setIcon(R.drawable.ic_launcher);
    		  videoBuffering.setTitle(R.string.app_name);
    		  videoBuffering.setProgressStyle(ProgressDialog.STYLE_SPINNER);
    		  videoBuffering.show();

    		  vid.setOnErrorListener(new OnErrorListener () {
    			  @Override
    			  public boolean onError(MediaPlayer mp, int what, int extra) {
    				  //Log.e(TAG, "Error playing video");
    				  Toast.makeText(getBaseContext(),"No Internet Connection",Toast.LENGTH_SHORT).show();
    				  return true;
    			  }
    		  });

    		  vid.setOnPreparedListener(new OnPreparedListener(){
    			  @Override
    			  public void onPrepared(MediaPlayer mp) {
    				  videoBuffering.dismiss();

    			  }
    		  });


    	  }
    	  // this is for the framelayout tabs, responding to clicks and changing the tabs interchangably 

    	  liveblog_tab = (LinearLayout) findViewById(R.id.liveblog_tab);
    	  addcom_tab = (LinearLayout) findViewById(R.id.addcom_tab);

    	  liveblog = (LinearLayout) findViewById(R.id.liveblog);
    	  comments = (LinearLayout) findViewById(R.id.comments);


    	  /*if (savedInstanceState != null){
    		  FLAG = savedInstanceState.getInt("flag");

    		  changeView();

    	  }

    	  else{

    		  changeView();

    	  }*/
    	  FLAG = LIVE_BLOG;

    	  ourBrow = (WebView) findViewById(R.id.browser);
    	  //adding webviewclient prevents web-view launching every-time the web-site is visited
    	  ourBrow.setWebViewClient(new WebViewClient());
    	  //ourBrow.getSettings().setBuiltInZoomControls(true);
    	  //ourBrow.getSettings().setSupportZoom(true);
    	  ourBrow.getSettings().setJavaScriptEnabled(true);
    	  ourBrow.getSettings().setAllowFileAccess(true);
    	  ourBrow.loadUrl("http://videoshare.loveworldapis.com/lwsatapp/comment.php");
    	  ourBrow.setWebViewClient(new WebViewClient()
    	  {
    		  public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
    			  ourBrow.loadUrl("file:///android_asset/internet.htm");
    		  }
    	  });


    	/*  liveblog_tab.setOnClickListener(new OnClickListener(){
    		  @Override
    		  public void onClick(View arg0) {
    			  FLAG = LIVE_BLOG;
    			  changeView();
    		  }
    	  });
       */

    	 
    	  addcom_tab.setOnClickListener(new OnClickListener(){
    		  @Override
    		  public void onClick(View arg0) {
    			  //FLAG = COMMENT;
    			  //changeView();
    			  viewCategory();

    		  }
    	  });
    	  
    	 refresh.setOnClickListener(new OnClickListener(){

    	            public void onClick(View v) {

    	                Intent i = new Intent(ArrowsActivity.this, FullVideoView.class);
    	                i.putExtra("video_url", "http://155.obj.netromedia.net/MobileStream/MobileStream/playlist.m3u8");
    	                startActivity(i);
    	            }
    	        });
      }
      private boolean validateEmailField(String email){
    	  email = email.trim();
    	  String reverse = new StringBuffer(email).reverse().toString();
    	  if (email == null || email.length() == 0 || email.indexOf("@") == -1) {
    		  return false;
    	  }
    	  int emailLength = email.length();
    	  int atPosition = email.indexOf("@");
    	  int atDot = reverse.indexOf(".");
    	  

    	  String beforeAt = email.substring(0, atPosition);
    	  String afterAt = email.substring(atPosition + 1, emailLength);

    	  if (beforeAt.length() == 0 || afterAt.length() == 0) {
    		  return false;
    	  }
    	  for (int i = 0; email.length() - 1 > i; i++) {
    		  char i1 = email.charAt(i);
    		  char i2 = email.charAt(i + 1);
    		  if (i1 == '.' && i2 == '.') {
    			  return false;
    		  }
    	  }
    	  if (email.charAt(atPosition - 1) == '.' || email.charAt(0) == '.' || email.charAt(atPosition + 1) == '.' || afterAt.indexOf("@") != -1 || atDot < 2) {
    		  return false;
    	  }

    	  return true;
      }
   /* private void changeView(){
 
    	  if (FLAG == LIVE_BLOG){

    		  comments.setVisibility(View.INVISIBLE);
    		  liveblog.setVisibility(View.VISIBLE);

    	  }

    	  else if (FLAG == COMMENT){

    		  liveblog.setVisibility(View.INVISIBLE);
    		  comments.setVisibility(View.VISIBLE);

    	  }
      }
      @Override
      protected void onRestoreInstanceState (Bundle savedInstanceState){

    	  FLAG = savedInstanceState.getInt("flag");
    	  changeView();

      }
      @Override

      protected void onSaveInstanceState (Bundle outState){

    	  outState.putInt("flag", FLAG);

      }  
*/
      /*    private boolean checkInternetConnection() {

 	ConnectivityManager conMgr = (ConnectivityManager) getSystemService (Context.CONNECTIVITY_SERVICE);
    // ARE WE CONNECTED TO THE NET
 	if (conMgr.getActiveNetworkInfo() != null
 	&& conMgr.getActiveNetworkInfo().isAvailable()
 	&& conMgr.getActiveNetworkInfo().isConnected()) {
 	return true;
 	} else {

 	 Log.v(TAG, "Internet Connection Not Present");

 	 return false;

       }*/

      // }

   }



