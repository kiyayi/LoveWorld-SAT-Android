package com.loveworldsat.app;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;

public class Shareapp extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_shareapp);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.shareapp, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		
		switch(item.getItemId()){
		case R.id.about:
			Intent a = new Intent(Shareapp.this, AboutLWSAT.class);
			startActivity(a);
			break; 
	    /*case R.id.itestify:
			Intent b = new Intent(Shareapp.this, Itestify.class);
			startActivity(b);	    	
			break;*/
	    case R.id.contact:
			Intent cc = new Intent(Shareapp.this, Contact.class);
			startActivity(cc);	    	
			break;			
		case R.id.feedback:
			Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);

			  /* Fill it with Data */

			  emailIntent.setType("plain/text");

			  emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"loveworldsat@loveworldmail.org.za"});

			  emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");

			  emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "");

			  /* Send it off to the Activity-Chooser */

			  startActivity(Intent.createChooser(emailIntent, "Send mail..."));

			  //finish();
			break;
		/*case R.id.schedule:
			Intent d = new Intent(Shareapp.this, Schedule.class);
			startActivity(d);
			break;*/
	  /* case R.id.share:
			Intent e = new Intent(Shareapp.this, Shareapp.class);
			startActivity(e);
			break;*/
		/*case R.id.iwitness:
			Intent f = new Intent(Shareapp.this, Iwitness.class);
			startActivity(f);
			break;*/
		/*case R.id.extras:
			Intent g = new Intent(Shareapp.this, Extras.class);
			startActivity(g);
			break; 		*/
		}
		return false;
	}
}