package com.loveworldsat.app;


import org.apache.http.HttpResponse;

public class HttpData {
	public String data;
	public HttpResponse response;

	public String getData() {
		return data;
	}

	public void setData(final String data) {
		this.data = data;
	}

	public HttpResponse getResponse() {
		return response;
	}

	public void setResponse(final HttpResponse response) {
		this.response = response;
	}
}
