package com.loveworldsat.app;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.VideoView;
import android.widget.AdapterView.OnItemSelectedListener;



@TargetApi(Build.VERSION_CODES.HONEYCOMB)

public class Itestify extends Activity {
	
	String name, email,comment, firstValue, secondValue;
	Button yes,postcomment;
	EditText nameField, emailField, countryField, commentField;

	String selItem;
	WebView ourBrow;
	
	private void viewCategory() {


  	  AlertDialog.Builder viewDialog = new AlertDialog.Builder(this);
  	  
  	  viewDialog.setTitle("LoveWorldSAT App");
  	  viewDialog.setIcon(R.drawable.ic_launcher);
  	  LayoutInflater li = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
  	  final View dialogView = li.inflate(R.layout.commentlayout2, null);
  	  viewDialog.setView(dialogView);
  	  viewDialog.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
  	  
  	  public void onClick(DialogInterface dialog, int whichButton) {
  	               nameField = (EditText) dialogView.findViewById(R.id.editText1);
  	               emailField = (EditText) dialogView.findViewById(R.id.editText2);
  	               commentField = (EditText) dialogView.findViewById(R.id.commentField);
  	               
  	               
  	            //get message from message fields
  	               String  name = nameField.getText().toString();
  	               String  emaila = emailField.getText().toString();
                     String  comm = commentField.getText().toString();
                     if(name.length()>0 && comm.length()>0) {
                  	   if (validateEmailField(emaila)){
                  		   doSubmitComment(name, emaila, comm);
                  	   }
                  	   else{
                  		   Toast.makeText(getApplicationContext(), "The Email Field is Invalid", Toast.LENGTH_LONG).show();
                  	   }
                     }
                     else {
                  	   //display message if text field is empty
                  	   Toast.makeText(getBaseContext(),"All fields are required",Toast.LENGTH_SHORT).show();
                     } 
  	  }

  	  });
  	  
  	  viewDialog.setNegativeButton("Cancel",
  			  new DialogInterface.OnClickListener() {
  		  public void onClick(DialogInterface dialog, int whichButton) {
  		  }
  	  });    
  	  viewDialog.show();
  	  Spinner spinnercategory = (Spinner) dialogView.findViewById(R.id.spinner);
  	  ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.category, android.R.layout.simple_spinner_item);
  	  adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
  	  spinnercategory.setAdapter(adapter);
  	  spinnercategory.setOnItemSelectedListener(new OnItemSelectedListener() {
  		  public void onItemSelected(AdapterView<?> parent, View arg1,
  				  int arg2, long arg3) {
  			  selItem = parent.getSelectedItem().toString();

  		  }
  		  public void onNothingSelected(AdapterView<?> arg0) {

  			  // TODO Auto-generated method stub

  		  }

  	  });

    }
    
    private void doSubmitComment(String name, String emaila, String comm){
  	  //check whether the name field is empty or not
        if(name.length()>0 && comm.length()>0) {

      	  HttpClient httpclient = new DefaultHttpClient();
      	  HttpPost httppost = new HttpPost("http://videoshare.loveworldapis.com/lwsatapp/post_cmt.php");

      	  try {
      		  List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(3);

      		  // nameValuePairs.add(new BasicNameValuePair("id", "01"));
      		  nameValuePairs.add(new BasicNameValuePair("name", name));
      		  nameValuePairs.add(new BasicNameValuePair("email", emaila));
      		  nameValuePairs.add(new BasicNameValuePair("country", selItem));
      		  nameValuePairs.add(new BasicNameValuePair("comment", comm));
      		  httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));   	              
      		  httpclient.execute(httppost);

      		  nameField.setText(""); //reset the message text field
      		  emailField.setText("");
      		  //countryField.setText("")
      		  commentField.setText("");

      		  Toast.makeText(getBaseContext(),"Sent. Your Testimony is awaitng approval",Toast.LENGTH_SHORT).show();
      	  } catch (ClientProtocolException e) {
      		  e.printStackTrace();
      	  } catch (IOException e) {
      		  e.printStackTrace();
      	  }   	                               
      	  ourBrow.reload();   
        }
        /*else {
      	  //display message if text field is empty
      	  Toast.makeText(getBaseContext(),"All fields are required",Toast.LENGTH_SHORT).show();
        } */
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
  	  super.onCreate(savedInstanceState);
  	  setContentView(R.layout.activity_itestify);
  	  {
  		  
  		ActionBar actionbar = getActionBar();
		actionbar.setDisplayHomeAsUpEnabled(true);
		
	    {

	    	postcomment = (Button) findViewById(R.id.post);
	    	
	   }
	    

	    ourBrow = (WebView) findViewById(R.id.testimonybrowser);
	    //adding webviewclient prevents web-view launching every-time the web-site is visited
	    ourBrow.setWebViewClient(new WebViewClient());
	    //ourBrow.getSettings().setBuiltInZoomControls(true);
	    //ourBrow.getSettings().setSupportZoom(true);
	    ourBrow.getSettings().setJavaScriptEnabled(true);
	    ourBrow.getSettings().setAllowFileAccess(true);
	    ourBrow.loadUrl("http://videoshare.loveworldapis.com/lwsatapp/testimonies.php");
	    ourBrow.setWebViewClient(new WebViewClient() {
	            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
	            ourBrow.loadUrl("file:///android_asset/internet.htm");
	            }
	        });
	
	     
	      postcomment.setOnClickListener(new OnClickListener(){
	      @Override
	       public void onClick(View arg0) {
	      //FLAG = COMMENT;
	      //changeView();
	      viewCategory();

	      }
	    });
	   }  
  	  }
  	  
  	 private boolean validateEmailField(String email){
   	  email = email.trim();
   	  String reverse = new StringBuffer(email).reverse().toString();
   	  if (email == null || email.length() == 0 || email.indexOf("@") == -1) {
   		  return false;
   	  }
   	  int emailLength = email.length();
   	  int atPosition = email.indexOf("@");
   	  int atDot = reverse.indexOf(".");
   	  

   	  String beforeAt = email.substring(0, atPosition);
   	  String afterAt = email.substring(atPosition + 1, emailLength);

   	  if (beforeAt.length() == 0 || afterAt.length() == 0) {
   		  return false;
   	  }
   	  for (int i = 0; email.length() - 1 > i; i++) {
   		  char i1 = email.charAt(i);
   		  char i2 = email.charAt(i + 1);
   		  if (i1 == '.' && i2 == '.') {
   			  return false;
   		  }
   	  }
   	  if (email.charAt(atPosition - 1) == '.' || email.charAt(0) == '.' || email.charAt(atPosition + 1) == '.' || afterAt.indexOf("@") != -1 || atDot < 2) {
   		  return false;
   	  }

   	  return true;
     }
	    @Override
        public boolean onCreateOptionsMenu(Menu menu) { 
                super.onCreateOptionsMenu(menu);
    	        MenuInflater inflater = getMenuInflater();
                inflater.inflate(R.menu.activity_main, menu);
                // setMenuBackground();
                return true;
        
}
	    
	    @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
		
		        switch(item.getItemId()){
		        
		        case android.R.id.home:
		        	finish();
		        	break;
		        
		        case R.id.about:
			
			    Intent a = new Intent(Itestify.this, AboutLWSAT.class);
			    startActivity(a);
			    break; 
			    
		        case R.id.social:		        	
		        	final CharSequence[] items = {"Yookos", "Facebook", "Twitter"};
					 
		        	//Prepare the list dialog box
		        	AlertDialog.Builder builder = new AlertDialog.Builder(this);

		        	//Set its title
		        	builder.setTitle("LoveWorldSAT Socials");

		        	//Set the list items and assign with the click listener
		        	builder.setItems(items, new DialogInterface.OnClickListener() {

		        	// Click listener
		            public void onClick(DialogInterface dialog, int items) {

		            switch (items){
		            	
		        	case 0:
			            Intent de = new Intent(Itestify.this, SATYookos.class);
			          	startActivity(de);
			            break;                   	
			                   	
			            case 1:
			            Intent mg = new Intent(Itestify.this, SATFacebook.class);
			           	startActivity(mg);
			            break;  	
			            
			            case 2:
			            Intent so = new Intent(Itestify.this, SATTwitter.class);
			           	startActivity(so);
			            break;  	
			            
		            
	}
	}

	});

		           	AlertDialog alert = builder.create();

		           	//display dialog box

		            alert.show();     
				  break;
			 		        	
	              case R.id.itestify:
			      Intent b = new Intent(Itestify.this, Itestify.class);
			      startActivity(b);	    	
			      break;
			
	              case R.id.contact:
		    	  Intent cc = new Intent(Itestify.this, Contact.class);
		    	  startActivity(cc);	
			
			      break;			
		          case R.id.feedback:
		    	  Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
		    	  
			      emailIntent.setType("plain/text");
			      emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"loveworldsat@loveworldmail.org.za"});
			      emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
		    	  emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "");
			
		    	  /* Send it off to the Activity-Chooser */
			     startActivity(Intent.createChooser(emailIntent, "Send mail..."));
			     //finish();
			      break;
			     
	             case R.id.share:
		         Intent sharingIntenta = new Intent(Intent.ACTION_SEND);		   
			     sharingIntenta.setType("text/plain");			
			     sharingIntenta.putExtra(android.content.Intent.EXTRA_SUBJECT,"LoveWorldSAT Mobile App");
	    	     sharingIntenta.putExtra(android.content.Intent.EXTRA_TEXT, "This is introducing the LoveWorldSAT Mobile Android App! Download now from the Google Play Store: http://bit.ly/lwsatand");
			     startActivity(Intent.createChooser(sharingIntenta,"Share using"));  

			      break;
		          case R.id.iwitness:
		          Intent iw = new Intent(Itestify.this, Iwitness.class);
		   	      startActivity(iw);
			      break;
			      
		          case R.id.extras:
		   	      final CharSequence[] items1 = {"Decoder Settings", "LoveWorldSAT Magazine"};

	        	  //Prepare the list dialog box
	        	  AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

	        	  //Set its title
	        	  builder1.setTitle("Extras");

	        	  //Set the list items and assign with the click listener
	        	  builder1.setItems(items1, new DialogInterface.OnClickListener() {

	        	  // Click listener
	              public void onClick(DialogInterface dialog, int items) {

	              switch (items){
	            	
	            	case 0:
	                Intent de = new Intent(Itestify.this, DecoderSetting.class);
	                startActivity(de);
	                break;                   	
	                   	
	                case 1:
	                Intent g = new Intent(Itestify.this, Magazine.class);
	           		startActivity(g);
	                break;  	
	}

	}

	});
	           	    AlertDialog alert1 = builder1.create();

	            	//display dialog box 

	                alert1.show();     
			        break; 		
	}
		            return false;
	}
	                @Override
	 
	                public void onConfigurationChanged(Configuration newConfig) {
	                super.onConfigurationChanged(newConfig);
	                getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

	}
	}

	
	     

