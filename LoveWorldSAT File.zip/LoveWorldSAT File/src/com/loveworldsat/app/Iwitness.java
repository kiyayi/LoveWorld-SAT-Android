package com.loveworldsat.app; 

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;

import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class Iwitness extends Activity {
	
	TextView path, path2;
	String selectedImagePath;
	String selectedFileName;
	ProgressDialog dialog = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_iwitness);
		
		ActionBar actionbar = getActionBar();
		actionbar.setDisplayHomeAsUpEnabled(true);
		
		Button btnUpload = (Button)findViewById(R.id.uplimg);
		Button btnSelect = (Button)findViewById(R.id.selimg);
		
		/*Button vidSelect = (Button)findViewById(R.id.selvid);
		Button vidUpload = (Button)findViewById(R.id.uplvid);*/
		
		path = (TextView) findViewById(R.id.txtmsg);
		path2 = (TextView) findViewById(R.id.txtmsg2);
		
		btnUpload.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				 dialog = ProgressDialog.show(Iwitness.this, "", "Uploading picture...", true);
                 new Thread(new Runnable() {
                        public void run() {
                                             
                        	doUpload();                    
                        }
                      }).start();        
                }
			
		});
		
		btnSelect.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				doSelect();
				
			}
			
		});
		
		//Video Uplolad
		
		/*vidSelect.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				doSelect();
				
			}
			
		});
		
		vidUpload.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				 dialog = ProgressDialog.show(Iwitness.this, "", "Uploading video...", true);
                 new Thread(new Runnable() {
                        public void run() {
                                             
                        	doUpload();                    
                        }
                      }).start();        
                }
			
		});*/
		
		
	}
	
	private void doUpload() {
		  try {
	           if (selectedImagePath != null){
	        	    Bitmap bm = BitmapFactory.decodeFile(selectedImagePath);
	        	    
	        	    executeMultipartPost(bm); 
	           }
	           
	        } catch (Exception e) {
	            Log.e(e.getClass().getName(), e.getMessage());
	        }
		
	}
	
	private void executeMultipartPost(Bitmap bm) throws Exception{
		  try {
	            ByteArrayOutputStream bos = new ByteArrayOutputStream();
	            bm.compress(CompressFormat.JPEG, 75, bos);
	            byte[] data = bos.toByteArray();
	            HttpClient httpClient = new DefaultHttpClient();
	            HttpPost postRequest = new HttpPost(
	                    "http://videoshare.loveworldapis.com/picupload/upload.php");
	            ByteArrayBody bab = new ByteArrayBody(data, selectedFileName + ".jpg");
	            // File file= new File("/mnt/sdcard/forest.png");
	            // FileBody bin = new FileBody(file);
	           
	            MultipartEntity reqEntity = new MultipartEntity(
	                    HttpMultipartMode.BROWSER_COMPATIBLE);
	            reqEntity.addPart("upload", bab);
	            reqEntity.addPart("title", new StringBody("I love Eko"));
	            postRequest.setEntity(reqEntity); 
	            
	            HttpResponse response = httpClient.execute(postRequest);
	            BufferedReader reader = new BufferedReader(new InputStreamReader(
	                    response.getEntity().getContent(), "UTF-8"));
	            String sResponse;
	            StringBuilder s = new StringBuilder();
	 
	            while ((sResponse = reader.readLine()) != null) {
	                s = s.append(sResponse);
	            }
	            Log.i("HTTP", "Response: " + s);
	            dialog.dismiss();
	        } catch (Exception e) {
	            // handle exception here
	        	dialog.dismiss();
	            Log.e(e.getClass().getName(), e.getMessage());
	            
	        }
	    }
		
	

	private void doSelect(){
		if (Environment.getExternalStorageState().equals("mounted")) {
		    Intent intent = new Intent();
		    intent.setType("image/*");
		    intent.setAction(Intent.ACTION_PICK);
		    startActivityForResult(Intent.createChooser(intent,"Select Picture:"),1);
		}
	}
	
	 @Override
     public boolean onCreateOptionsMenu(Menu menu) { 
             super.onCreateOptionsMenu(menu);
 	        MenuInflater inflater = getMenuInflater();
             inflater.inflate(R.menu.activity_main, menu);
             // setMenuBackground();
             return true;
     
}
	    
	    @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
		
		        switch(item.getItemId()){
		        
		        case android.R.id.home:
		        	finish();
		        	break;
		        
		        case R.id.about:
			
			    Intent a = new Intent(Iwitness.this, AboutLWSAT.class);
			    startActivity(a);
			    break; 
			    
		        case R.id.social:		        	
		        	final CharSequence[] items = {"Yookos", "Facebook", "Twitter"};
					 
		        	//Prepare the list dialog box
		        	AlertDialog.Builder builder = new AlertDialog.Builder(this);

		        	//Set its title
		        	builder.setTitle("LoveWorldSAT Socials");

		        	//Set the list items and assign with the click listener
		        	builder.setItems(items, new DialogInterface.OnClickListener() {

		        	// Click listener
		            public void onClick(DialogInterface dialog, int items) {

		            switch (items){
		            	
		        	case 0:
			            Intent de = new Intent(Iwitness.this, SATYookos.class);
			          	startActivity(de);
			            break;                   	
			                   	
			            case 1:
			            Intent mg = new Intent(Iwitness.this, SATFacebook.class);
			           	startActivity(mg);
			            break;  	
			            
			            case 2:
			            Intent so = new Intent(Iwitness.this, SATTwitter.class);
			           	startActivity(so);
			            break;  	
			            
		            
	}
	}

	});

		           	AlertDialog alert = builder.create();

		           	//display dialog box

		            alert.show();     
				  break;
			 		        	
	              case R.id.itestify:
			      Intent b = new Intent(Iwitness.this, Itestify.class);
			      startActivity(b);	    	
			      break;
			
	              case R.id.contact:
		    	  Intent cc = new Intent(Iwitness.this, Contact.class);
		    	  startActivity(cc);	
			
			      break;			
		          case R.id.feedback:
		    	  Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
		    	  
			      emailIntent.setType("plain/text");
			      emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"loveworldsat@loveworldmail.org.za"});
			      emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
		    	  emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "");
			
		    	  /* Send it off to the Activity-Chooser */
			     startActivity(Intent.createChooser(emailIntent, "Send mail..."));
			     //finish();
			      break;
			     
	             case R.id.share:
		         Intent sharingIntenta = new Intent(Intent.ACTION_SEND);		   
			     sharingIntenta.setType("text/plain");			
			     sharingIntenta.putExtra(android.content.Intent.EXTRA_SUBJECT,"LoveWorldSAT Mobile App");
	    	     sharingIntenta.putExtra(android.content.Intent.EXTRA_TEXT, "This is introducing the LoveWorldSAT Mobile Android App! Download now from the Google Play Store: http://bit.ly/lwsatand");
			     startActivity(Intent.createChooser(sharingIntenta,"Share using"));  

			      break;
		          case R.id.iwitness:
		          Intent iw = new Intent(Iwitness.this, Iwitness.class);
		   	      startActivity(iw);
			      break;
			      
		          case R.id.extras:
		   	      final CharSequence[] items1 = {"Decoder Settings", "LoveWorldSAT Magazine"};

	        	  //Prepare the list dialog box
	        	  AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

	        	  //Set its title
	        	  builder1.setTitle("Extras");

	        	  //Set the list items and assign with the click listener
	        	  builder1.setItems(items1, new DialogInterface.OnClickListener() {

	        	  // Click listener
	              public void onClick(DialogInterface dialog, int items) {

	              switch (items){
	            	
	            	case 0:
	                Intent de = new Intent(Iwitness.this, DecoderSetting.class);
	                startActivity(de);
	                break;                   	
	                   	
	                case 1:
	                Intent g = new Intent(Iwitness.this, Magazine.class);
	           		startActivity(g);
	                break;  	
	}

	}

	});
	           	    AlertDialog alert1 = builder1.create();

	            	//display dialog box 

	                alert1.show();     
			        break; 		
	}
		            return false;
	}
	                @Override
	 
	                public void onConfigurationChanged(Configuration newConfig) {
	                super.onConfigurationChanged(newConfig);
	                getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

	}
	

	
	     


	
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	
		
		if (resultCode != RESULT_CANCELED){
			if (requestCode  == 1){
				Uri selectedImageUri = data.getData();
			    selectedImagePath = getPath(selectedImageUri);
			    path.setText(selectedImagePath);
			    Log.i("IMAGE NAME", selectedFileName = getFileName(selectedImageUri));
			    
			    Log.i("FILE SIZE", getSize(selectedImageUri));
			    
			  
			    
			}
			
		}
	    
	}
	
	public String getPath(Uri uri) {
	    String[] projection = { MediaStore.Images.Media.DATA };
	    Cursor cursor = managedQuery(uri, projection, null, null, null);
	    int column_index = cursor
	        .getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
	    cursor.moveToFirst();
	    return cursor.getString(column_index);
	}
	
	public String getFileName(Uri uri){
		String[] projection = { MediaStore.Images.Media.TITLE };
	    Cursor cursor = managedQuery(uri, projection, null, null, null);
	    int column_index = cursor
	        .getColumnIndexOrThrow(MediaStore.Images.Media.TITLE);
	    cursor.moveToFirst();
	    return cursor.getString(column_index);
	}
	
	public String getSize(Uri uri){
		String[] projection = { MediaStore.Images.Media.SIZE };
	    Cursor cursor = managedQuery(uri, projection, null, null, null);
	    int column_index = cursor
	        .getColumnIndexOrThrow(MediaStore.Images.Media.SIZE);
	    cursor.moveToFirst();
	    return cursor.getString(column_index);
	    
	}
		
	
}
