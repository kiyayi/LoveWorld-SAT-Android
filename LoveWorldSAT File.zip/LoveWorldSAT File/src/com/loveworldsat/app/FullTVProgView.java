package com.loveworldsat.app;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;


import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;


public class FullTVProgView extends Activity {
	private ProgressDialog progressDialog;

	private Activity activity;
	private Context con;
	ImageView back;
	private VideoView videoView;
	private String videourl = "";

	ListView lv;
	private ProgressDialog pDialog;
	private Context context;
	// private int songid;
	// private String songurl = "";
	File videoFile = null;
	
	final Handler h = new Handler();

	/** Called when the activity is first created. */
	@Override
	public void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.full_view2);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		context = this;
		
		videourl = "";


		back = (ImageView) findViewById(R.id.back2);
		back.setFocusable(true);
		back.setVisibility(View.VISIBLE);
		back.setOnClickListener(new OnClickListener() {public void onClick(View v) {

            Intent i = new Intent(FullTVProgView.this, MainActivity.class);
          
            startActivity(i);
        }});

		h.postDelayed(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				back.setVisibility(View.INVISIBLE);
			}
		}, 4000);

		// songid = R.string.filename;
		// songurl = "http://www.procruncher.com/android/video-02.mp4";

		activity = this;
		// position = getIntent().getIntExtra("pos", 0);
		// Log.w("position initial :", position + "");

		con = this;
		// flip.setDisplayedChild(1);
		videourl = getIntent().getExtras().getString("video_url");
		// Uri video = Uri.parse("videourl");
		Toast.makeText(getApplicationContext(), "Please wait while stream loads..", Toast.LENGTH_LONG).show();
		playvedio(videourl);
		// playurl(songurl);
		


	}



	private void playvedio(final String fname) {
		videoView = (VideoView) activity.findViewById(R.id.myvideoview);
		videoView.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View arg0, MotionEvent arg1) {
				// TODO Auto-generated method stub
				back.setVisibility(View.VISIBLE);

				h.postDelayed(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						back.setVisibility(View.INVISIBLE);
					}
				}, 4000);
				return false;
			}
		});

		videoView.setOnPreparedListener(new OnPreparedListener() {

			@Override
			public void onPrepared(final MediaPlayer mp) {
				if (progressDialog != null) {
					progressDialog.cancel();
				}
			}
		});

		videoView.setOnErrorListener(new OnErrorListener() {

			@Override
			public boolean onError(final MediaPlayer arg0, final int arg1,
					final int arg2) {
				// TODO Auto-generated method stub

				if (progressDialog != null) {
					progressDialog.cancel();
				}

				return false;
			}
		});
		final MediaController mediaController = new MediaController(con);

		mediaController.show(1000);

		videoView.setMediaController(mediaController);

		if (SharedPreferencesHelper.isOnline(context)) {	
			
			try{
				playurl(fname);
				
				}catch(Exception e){
					   Log.d("network problem:", e.toString());
				}
			
				
	} else {
		AlertMessage.showMessage(this, "Info", "No internet");
	}

	}

	private void playurl(String url) {
		try {
			progressDialog = ProgressDialog.show(FullTVProgView.this,
			"Please wait...", "Loading...", false, false);
			url = URLEncoder.encode(url, "UTF-8");
			videoView.setVideoURI(Uri.parse(url));
			videoView.requestFocus();
			videoView.start();

			videoView.setOnPreparedListener(new OnPreparedListener() {

				@Override
				public void onPrepared(final MediaPlayer mp) {

					if (progressDialog != null) {
						progressDialog.cancel();
					}
//
				}
			});

			videoView.setOnErrorListener(new OnErrorListener() {

				@Override
				public boolean onError(final MediaPlayer arg0, final int arg1,
						final int arg2) {
					// TODO Auto-generated method stub

					if (progressDialog != null) {
						progressDialog.cancel();
					}

					return false;
				}
			});

		} catch (final UnsupportedEncodingException e) {
			if (progressDialog != null) {
				progressDialog.cancel();
			}
			Toast.makeText(con, "Can't play", Toast.LENGTH_SHORT).show();
			finish();
			e.printStackTrace();

		}

	}
}
