package com.loveworldsat.app;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class LiveTvDialog extends Activity{

	EditText namefield,emailfield,countryfield, commentfield;
	Button sendbutton, cancelbutton;
	Spinner spinner;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.testimony);
		
		// Spinner spinner = (Spinner)findViewById(R.id.spinner);
	    namefield = (EditText) findViewById(R.id.editText1);
		emailfield = (EditText) findViewById(R.id.editText2);
   	    commentfield = (EditText) findViewById(R.id.commentField);
   	    spinner = (Spinner)findViewById(R.id.spinner);
   	    //sendbutton = (Button) findViewById(R.id.sumbit);
   	   // cancelbutton=(Button) findViewById(R.id.tvcancel);
   	 
  ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.category, android.R.layout.simple_spinner_item);
  adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
  spinner.setAdapter(adapter);
}

	
	

@SuppressLint("NewApi")

   public void send(View v){
	
    //get message from message box
    String  nam = namefield.getText().toString();
    String  eemail= emailfield.getText().toString();
    String  ecomment= commentfield.getText().toString();
    String  ecountry= spinner.getSelectedItem().toString();
    
	   StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

	   StrictMode.setThreadPolicy(policy); 
    
    //check whether the msg empty or not
    if(nam.length()>0) {
        HttpClient httpclient = new DefaultHttpClient();
        HttpPost httppost = new HttpPost("http://videoshare.loveworldapis.com/lw_music/contents/postcomments/");
         
        try {
            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(5);
            nameValuePairs.add(new BasicNameValuePair("id", "01"));
            nameValuePairs.add(new BasicNameValuePair("name", nam));
            nameValuePairs.add(new BasicNameValuePair("email", eemail));
            nameValuePairs.add(new BasicNameValuePair("country", ecountry));
            nameValuePairs.add(new BasicNameValuePair("comment", ecomment));
               httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
               httpclient.execute(httppost);
               
               
               namefield.setText(""); 
               emailfield.setText("");
               //spinner.setText("");
               commentfield.setText("");
               //spinner.setContentDescription("");
            
                Toast.makeText(getBaseContext(),"Comment Sent",Toast.LENGTH_SHORT).show();
                finish();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    } else {
        //display message if text field is empty
        Toast.makeText(getBaseContext(),"All fields are necessary",Toast.LENGTH_SHORT).show();
    }


 
    
    
/*	  cancelbutton.setOnClickListener(new OnClickListener() {

        @Override
        public void onClick(View v) {
            finish();            
        }
    });*/

}
}
	
	/*EditText name,email,country, comment;
    Button send;
    Spinner spinner;
    private Button button;
    int status;
	String message;
	JSONParser jparser = new JSONParser();
	JSONObject json;
	ArrayList<NameValuePair> posts;
	
	String strname, stremail, strcountry, strcomment;
	
	private static final String TAG_SUCCESS = "success";
	
	private static final String TAG_MESSAGE= "message";		
	
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.livetvdialog);
        
        button = (Button) findViewById(R.id.tvcancel);
        
        EditText text = (EditText)findViewById(R.id.livetvname);
		
		Spinner spinner = (Spinner)findViewById(R.id.spinner1);
				
		EditText text2 = (EditText) findViewById(R.id.livetvcomment);
		
		EditText text3 = (EditText) findViewById(R.id.livetvemail);
		
		// Spinner spinner = (Spinner)findViewById(R.id.spinner);
	    name = (EditText) findViewById(R.id.comment_author_name);
	    
		email = (EditText) findViewById(R.id.comment_author_email);
		
   	    comment = (EditText) findViewById(R.id.comment);
   	    
   	    spinner = (Spinner)findViewById(R.id.spcountry);
   	    
   	    button = (Button) findViewById(R.id.tvpost);
   	    
   	    button.setOnClickListener(postcommentlistener);
   	    
   	
}
	
	  public OnClickListener postcommentlistener = new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				strname = name.getText().toString();
				
				stremail = email.getText().toString();
				
				strcomment = comment.getText().toString();
				
				strcountry = spinner.getItemAtPosition(spinner.getSelectedItemPosition()).toString();
				
				//send();
				//Toast.makeText(getApplicationContext(), "kelvin", 1).show();
				new PostComment().execute();
			}
};


public class PostComment extends AsyncTask<Void, Void, Void> implements DialogInterface.OnCancelListener{

	ProgressDialog dialog;
	String flag;
	@Override
	public void onCancel(DialogInterface dialog) {
		// TODO Auto-generated method stub
		cancel(true);
		dialog.dismiss();
	}
	
	
	
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		dialog = ProgressDialog.show(LiveTvDialog.this, "", "Processing data...", true);
	}



	@SuppressLint("NewApi")
	@Override
	protected Void doInBackground(Void... arg0) {
		// TODO Auto-generated method stub
		posts = new ArrayList<NameValuePair>();
		
		posts.add(new BasicNameValuePair("name", strname));
		
		posts.add(new BasicNameValuePair("email", stremail));
		
		posts.add(new BasicNameValuePair("country", strcountry));
		
		posts.add(new BasicNameValuePair("comment", strcomment));
		
		StrictMode.ThreadPolicy old = StrictMode.getThreadPolicy();
		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder(old)
		    .permitDiskWrites()
		    .build());
		//doCorrectStuffThatWritesToDisk();
		StrictMode.setThreadPolicy(old);
		
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

		StrictMode.setThreadPolicy(policy);
		
	
		json = jparser.makeHttpRequest("http://videoshare.loveworldapis.com/lw_music/contents/postcomments/", "POST", posts);
		
		try {
			if(json.length() > 0){
				status = json.getInt(TAG_SUCCESS);
				message = json.getString(TAG_MESSAGE);
			}else{
				flag = "not parsing";
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null; 
		
		
	}

	
	@Override
	protected void onPostExecute(Void result) {
		// TODO Auto-generated method stub
		super.onPostExecute(result);
	   
		Toast.makeText(getApplicationContext(), flag, 1).show();
		
		if(status==1){
			
			Toast.makeText(getApplicationContext(), message, 1).show();
			
		}
		
		if(status==0){
			
			Toast.makeText(getApplicationContext(), message, 1).show();
		}
		
		if(status==2){
			
			Toast.makeText(getApplicationContext(), message, 1).show();
			
		}
		
		dialog.dismiss();
	}
	
	
}//end async task

public void send(){
	   	 Toast.makeText(getApplicationContext(), strname, 1).show();
	
}//end send

}//end major class


*/