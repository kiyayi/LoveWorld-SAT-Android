package com.loveworldsat.app;



import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.loveworldsat.app.R;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)

public class SATFacebook extends Activity {
	WebView html;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
		//requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
	    setContentView(R.layout.activity_facebook);
	   //getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE,R.layout.banner);
	  //  getSupportActionBar().setDisplayHomeAsUpEnabled(true);
          
	    ActionBar actionbar = getActionBar();
		actionbar.setDisplayHomeAsUpEnabled(true);
	    
	    html = (WebView) findViewById(R.id.lwsatfacebook);
	    html.loadUrl("https://www.facebook.com/pages/LoveWorldSAT/209486219095815");
	    html.setWebViewClient(new WebViewClient());
	    html.getSettings().setUseWideViewPort(true);
	    //html.getSettings().setLoadWithOverviewMode(true);
	    html.getSettings().setJavaScriptEnabled(true);
	   
	    
	    
	    html.setWebViewClient(new WebViewClient() {
	    	@Override
	        public boolean shouldOverrideUrlLoading(WebView view, String url) 
	        {
	            return false;
	        }
	    	@Override
	        public void onPageStarted(WebView view, String url, Bitmap favicon) {
	            super.onPageStarted(view, url, favicon);
	          
	            setProgressBarIndeterminateVisibility(true);
	        }
	    	
	    	  @Override
		        public void onPageFinished(WebView view, String url) {

		           
		        	if(isOnline())
	        		{
		        		setProgressBarIndeterminateVisibility(false);
	        		}
	        		else{
	        			AlertDialog NetAlert = new AlertDialog.Builder(SATFacebook.this).create();
						NetAlert.setMessage("No internet conection, please check your internet connection before trying again!");
						NetAlert.setButton("OK", new DialogInterface.OnClickListener() {
						      public void onClick(DialogInterface dialog, int which) {
						 
						       //here you can add functions
						 finish();
						    
						      } });
						NetAlert.show();
						
						setProgressBarIndeterminateVisibility(false);
	        		}
	    	  }
	    	  
	    	  
	           public void onReceivedError(WebView view, int errorCode, String description, String failingUrl){
	            html.loadUrl("file:///android_asset/internet.htm");
	            }
	           
	    	public boolean isOnline(){
	    		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
	    		NetworkInfo ni = cm.getActiveNetworkInfo();
	    		
	    		if (ni != null && ni.isConnectedOrConnecting())
	    		{
	    			return true;
	    		}
	    		else{
	    			return false;
	    		}
	    		
	        }
	    });
	}

	    	  
	           public void onReceivedError(WebView view, int errorCode, String description, String failingUrl){
	            html.loadUrl("file:///android_asset/internet.htm");

	            }
		          
		      
	        	public boolean isOnline(){
		    		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		    		NetworkInfo ni = cm.getActiveNetworkInfo();
		    		
		    		if (isOnline())
		    		{
		    		 // my code
		    		}
		    		else
		    		    {
		    			SATFacebook.this.startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); 
		    		    try {
		    		AlertDialog alertDialog = new AlertDialog.Builder(SATFacebook.this).create();

		    		alertDialog.setTitle("Info");
		    		alertDialog.setMessage("Internet not available, Cross check your internet connectivity and try again");
		    		//alertDialog.setIcon(R.drawable.alerticon);
		    		alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
		    		   public void onClick(DialogInterface dialog, int which) {
		    		     finish();

		    		   }
		    		});

		    		alertDialog.show();
		    		}
		    		catch(Exception e)
		    		{
		    		    //Log.d(Constants.TAG, "Show Dialog: "+e.getMessage());
		    		}
		    		    }
					return false;

}
	        	@Override
	            public boolean onCreateOptionsMenu(Menu menu) { 
	                super.onCreateOptionsMenu(menu);
	            	MenuInflater inflater = getMenuInflater();
	                inflater.inflate(R.menu.activity_main, menu);
	               // setMenuBackground();
	                return true;
	                
	            }

	        	@Override
	            public boolean onOptionsItemSelected(MenuItem item) {
	        	
	        	        switch(item.getItemId()){
	        	        
	        	        case android.R.id.home:
	        	        	finish();
	        	        	break;
	        	        
	        	        case R.id.about:
	        		
	        		    Intent a = new Intent(SATFacebook.this, AboutLWSAT.class);
	        		    startActivity(a);
	        		    break; 
	        		    
	        	        case R.id.social:		        	
	        	        	final CharSequence[] items = {"Yookos", "Facebook", "Twitter"};
	        				 
	        	        	//Prepare the list dialog box
	        	        	AlertDialog.Builder builder = new AlertDialog.Builder(this);

	        	        	//Set its title
	        	        	builder.setTitle("LoveWorldSAT Socials");

	        	        	//Set the list items and assign with the click listener
	        	        	builder.setItems(items, new DialogInterface.OnClickListener() {

	        	        	// Click listener
	        	            public void onClick(DialogInterface dialog, int items) {

	        	            switch (items){
	        	            	
	        	        	case 0:
	        		            Intent de = new Intent(SATFacebook.this, SATYookos.class);
	        		          	startActivity(de);
	        		            break;                   	
	        		                   	
	        		            case 1:
	        		            Intent mg = new Intent(SATFacebook.this, SATFacebook.class);
	        		           	startActivity(mg);
	        		            break;  	
	        		            
	        		            case 2:
	        		            Intent so = new Intent(SATFacebook.this, SATTwitter.class);
	        		           	startActivity(so);
	        		            break;  	
	        		            
	        	            
	        }
	        }

	        });

	        	           	AlertDialog alert = builder.create();

	        	           	//display dialog box

	        	            alert.show();     
	        			  break;
	        		 		        	
	                      case R.id.itestify:
	        		      Intent b = new Intent(SATFacebook.this, Itestify.class);
	        		      startActivity(b);	    	
	        		      break;
	        		
	                      case R.id.contact:
	        	    	  Intent cc = new Intent(SATFacebook.this, Contact.class);
	        	    	  startActivity(cc);	
	        		
	        		      break;			
	        	          case R.id.feedback:
	        	    	  Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
	        	    	  
	        		      emailIntent.setType("plain/text");
	        		      emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"loveworldsat@loveworldmail.org.za"});
	        		      emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
	        	    	  emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "");
	        		
	        	    	  /* Send it off to the Activity-Chooser */
	        		     startActivity(Intent.createChooser(emailIntent, "Send mail..."));
	        		     //finish();
	        		      break;
	        		     
	                     case R.id.share:
	        	         Intent sharingIntenta = new Intent(Intent.ACTION_SEND);		   
	        		     sharingIntenta.setType("text/plain");			
	        		     sharingIntenta.putExtra(android.content.Intent.EXTRA_SUBJECT,"LoveWorldSAT Mobile App");
	            	     sharingIntenta.putExtra(android.content.Intent.EXTRA_TEXT, "This is introducing the LoveWorldSAT Mobile Android App! Download now from the Google Play Store: http://bit.ly/lwsatand ");
	        		     startActivity(Intent.createChooser(sharingIntenta,"Share using"));  

	        		      break;
	        	          case R.id.iwitness:
	        	          Intent iw = new Intent(SATFacebook.this, Iwitness.class);
	        	   	      startActivity(iw);
	        		      break;
	        		      
	        	          case R.id.extras:
	        	   	      final CharSequence[] items1 = {"Decoder Settings", "LoveWorldSAT Magazine"};

	                	  //Prepare the list dialog box
	                	  AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

	                	  //Set its title
	                	  builder1.setTitle("Extras");

	                	  //Set the list items and assign with the click listener
	                	  builder1.setItems(items1, new DialogInterface.OnClickListener() {

	                	  // Click listener
	                      public void onClick(DialogInterface dialog, int items) {

	                      switch (items){
	                    	
	                    	case 0:
	                        Intent de = new Intent(SATFacebook.this, DecoderSetting.class);
	                        startActivity(de);
	                        break;                   	
	                           	
	                        case 1:
	                        Intent g = new Intent(SATFacebook.this, Magazine.class);
	                   		startActivity(g);
	                        break;  	
	        }

	        }

	        });
	                   	    AlertDialog alert1 = builder1.create();

	                    	//display dialog box 

	                        alert1.show();     
	        		        break; 		
	        }
	        	            return false;
	        }
	                        @Override
	         
	                        public void onConfigurationChanged(Configuration newConfig) {
	                        super.onConfigurationChanged(newConfig);
	                        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

	        }
	        }

